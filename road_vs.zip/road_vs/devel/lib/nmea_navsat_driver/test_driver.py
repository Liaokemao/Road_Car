#!/usr/bin/env bash
exec /home/passoni/road_vs/devel/share/nmea_navsat_driver/venv/bin/python /home/passoni/road_vs/src/nmea_navsat_driver/test/test_driver.py "$@"
