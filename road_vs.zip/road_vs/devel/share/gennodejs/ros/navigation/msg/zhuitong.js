// Auto-generated. Do not edit!

// (in-package navigation.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class zhuitong {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.zhuitong1_latitude = null;
      this.zhuitong1_longitude = null;
      this.zhuitong2_latitude = null;
      this.zhuitong2_longitude = null;
      this.zhuitong3_latitude = null;
      this.zhuitong3_longitude = null;
      this.zhuitong4_latitude = null;
      this.zhuitong4_longitude = null;
    }
    else {
      if (initObj.hasOwnProperty('zhuitong1_latitude')) {
        this.zhuitong1_latitude = initObj.zhuitong1_latitude
      }
      else {
        this.zhuitong1_latitude = 0.0;
      }
      if (initObj.hasOwnProperty('zhuitong1_longitude')) {
        this.zhuitong1_longitude = initObj.zhuitong1_longitude
      }
      else {
        this.zhuitong1_longitude = 0.0;
      }
      if (initObj.hasOwnProperty('zhuitong2_latitude')) {
        this.zhuitong2_latitude = initObj.zhuitong2_latitude
      }
      else {
        this.zhuitong2_latitude = 0.0;
      }
      if (initObj.hasOwnProperty('zhuitong2_longitude')) {
        this.zhuitong2_longitude = initObj.zhuitong2_longitude
      }
      else {
        this.zhuitong2_longitude = 0.0;
      }
      if (initObj.hasOwnProperty('zhuitong3_latitude')) {
        this.zhuitong3_latitude = initObj.zhuitong3_latitude
      }
      else {
        this.zhuitong3_latitude = 0.0;
      }
      if (initObj.hasOwnProperty('zhuitong3_longitude')) {
        this.zhuitong3_longitude = initObj.zhuitong3_longitude
      }
      else {
        this.zhuitong3_longitude = 0.0;
      }
      if (initObj.hasOwnProperty('zhuitong4_latitude')) {
        this.zhuitong4_latitude = initObj.zhuitong4_latitude
      }
      else {
        this.zhuitong4_latitude = 0.0;
      }
      if (initObj.hasOwnProperty('zhuitong4_longitude')) {
        this.zhuitong4_longitude = initObj.zhuitong4_longitude
      }
      else {
        this.zhuitong4_longitude = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type zhuitong
    // Serialize message field [zhuitong1_latitude]
    bufferOffset = _serializer.float64(obj.zhuitong1_latitude, buffer, bufferOffset);
    // Serialize message field [zhuitong1_longitude]
    bufferOffset = _serializer.float64(obj.zhuitong1_longitude, buffer, bufferOffset);
    // Serialize message field [zhuitong2_latitude]
    bufferOffset = _serializer.float64(obj.zhuitong2_latitude, buffer, bufferOffset);
    // Serialize message field [zhuitong2_longitude]
    bufferOffset = _serializer.float64(obj.zhuitong2_longitude, buffer, bufferOffset);
    // Serialize message field [zhuitong3_latitude]
    bufferOffset = _serializer.float64(obj.zhuitong3_latitude, buffer, bufferOffset);
    // Serialize message field [zhuitong3_longitude]
    bufferOffset = _serializer.float64(obj.zhuitong3_longitude, buffer, bufferOffset);
    // Serialize message field [zhuitong4_latitude]
    bufferOffset = _serializer.float64(obj.zhuitong4_latitude, buffer, bufferOffset);
    // Serialize message field [zhuitong4_longitude]
    bufferOffset = _serializer.float64(obj.zhuitong4_longitude, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type zhuitong
    let len;
    let data = new zhuitong(null);
    // Deserialize message field [zhuitong1_latitude]
    data.zhuitong1_latitude = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [zhuitong1_longitude]
    data.zhuitong1_longitude = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [zhuitong2_latitude]
    data.zhuitong2_latitude = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [zhuitong2_longitude]
    data.zhuitong2_longitude = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [zhuitong3_latitude]
    data.zhuitong3_latitude = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [zhuitong3_longitude]
    data.zhuitong3_longitude = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [zhuitong4_latitude]
    data.zhuitong4_latitude = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [zhuitong4_longitude]
    data.zhuitong4_longitude = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 64;
  }

  static datatype() {
    // Returns string type for a message object
    return 'navigation/zhuitong';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'da01d1f1947b10f527bc21e141aa08c9';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64 zhuitong1_latitude
    float64 zhuitong1_longitude
    float64 zhuitong2_latitude
    float64 zhuitong2_longitude
    float64 zhuitong3_latitude
    float64 zhuitong3_longitude
    float64 zhuitong4_latitude
    float64 zhuitong4_longitude
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new zhuitong(null);
    if (msg.zhuitong1_latitude !== undefined) {
      resolved.zhuitong1_latitude = msg.zhuitong1_latitude;
    }
    else {
      resolved.zhuitong1_latitude = 0.0
    }

    if (msg.zhuitong1_longitude !== undefined) {
      resolved.zhuitong1_longitude = msg.zhuitong1_longitude;
    }
    else {
      resolved.zhuitong1_longitude = 0.0
    }

    if (msg.zhuitong2_latitude !== undefined) {
      resolved.zhuitong2_latitude = msg.zhuitong2_latitude;
    }
    else {
      resolved.zhuitong2_latitude = 0.0
    }

    if (msg.zhuitong2_longitude !== undefined) {
      resolved.zhuitong2_longitude = msg.zhuitong2_longitude;
    }
    else {
      resolved.zhuitong2_longitude = 0.0
    }

    if (msg.zhuitong3_latitude !== undefined) {
      resolved.zhuitong3_latitude = msg.zhuitong3_latitude;
    }
    else {
      resolved.zhuitong3_latitude = 0.0
    }

    if (msg.zhuitong3_longitude !== undefined) {
      resolved.zhuitong3_longitude = msg.zhuitong3_longitude;
    }
    else {
      resolved.zhuitong3_longitude = 0.0
    }

    if (msg.zhuitong4_latitude !== undefined) {
      resolved.zhuitong4_latitude = msg.zhuitong4_latitude;
    }
    else {
      resolved.zhuitong4_latitude = 0.0
    }

    if (msg.zhuitong4_longitude !== undefined) {
      resolved.zhuitong4_longitude = msg.zhuitong4_longitude;
    }
    else {
      resolved.zhuitong4_longitude = 0.0
    }

    return resolved;
    }
};

module.exports = zhuitong;
