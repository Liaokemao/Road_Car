
"use strict";

let basecontrol = require('./basecontrol.js');

module.exports = {
  basecontrol: basecontrol,
};
