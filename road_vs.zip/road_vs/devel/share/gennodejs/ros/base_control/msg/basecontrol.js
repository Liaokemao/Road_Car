// Auto-generated. Do not edit!

// (in-package base_control.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class basecontrol {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.Vel_motor_fl = null;
      this.Vel_motor_rl = null;
      this.Vel_motor_fr = null;
      this.Vel_motor_rr = null;
      this.Angel_motor_fl = null;
      this.Angel_motor_rl = null;
      this.Angel_motor_fr = null;
      this.Angel_motor_rr = null;
    }
    else {
      if (initObj.hasOwnProperty('Vel_motor_fl')) {
        this.Vel_motor_fl = initObj.Vel_motor_fl
      }
      else {
        this.Vel_motor_fl = 0.0;
      }
      if (initObj.hasOwnProperty('Vel_motor_rl')) {
        this.Vel_motor_rl = initObj.Vel_motor_rl
      }
      else {
        this.Vel_motor_rl = 0.0;
      }
      if (initObj.hasOwnProperty('Vel_motor_fr')) {
        this.Vel_motor_fr = initObj.Vel_motor_fr
      }
      else {
        this.Vel_motor_fr = 0.0;
      }
      if (initObj.hasOwnProperty('Vel_motor_rr')) {
        this.Vel_motor_rr = initObj.Vel_motor_rr
      }
      else {
        this.Vel_motor_rr = 0.0;
      }
      if (initObj.hasOwnProperty('Angel_motor_fl')) {
        this.Angel_motor_fl = initObj.Angel_motor_fl
      }
      else {
        this.Angel_motor_fl = 0.0;
      }
      if (initObj.hasOwnProperty('Angel_motor_rl')) {
        this.Angel_motor_rl = initObj.Angel_motor_rl
      }
      else {
        this.Angel_motor_rl = 0.0;
      }
      if (initObj.hasOwnProperty('Angel_motor_fr')) {
        this.Angel_motor_fr = initObj.Angel_motor_fr
      }
      else {
        this.Angel_motor_fr = 0.0;
      }
      if (initObj.hasOwnProperty('Angel_motor_rr')) {
        this.Angel_motor_rr = initObj.Angel_motor_rr
      }
      else {
        this.Angel_motor_rr = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type basecontrol
    // Serialize message field [Vel_motor_fl]
    bufferOffset = _serializer.float32(obj.Vel_motor_fl, buffer, bufferOffset);
    // Serialize message field [Vel_motor_rl]
    bufferOffset = _serializer.float32(obj.Vel_motor_rl, buffer, bufferOffset);
    // Serialize message field [Vel_motor_fr]
    bufferOffset = _serializer.float32(obj.Vel_motor_fr, buffer, bufferOffset);
    // Serialize message field [Vel_motor_rr]
    bufferOffset = _serializer.float32(obj.Vel_motor_rr, buffer, bufferOffset);
    // Serialize message field [Angel_motor_fl]
    bufferOffset = _serializer.float32(obj.Angel_motor_fl, buffer, bufferOffset);
    // Serialize message field [Angel_motor_rl]
    bufferOffset = _serializer.float32(obj.Angel_motor_rl, buffer, bufferOffset);
    // Serialize message field [Angel_motor_fr]
    bufferOffset = _serializer.float32(obj.Angel_motor_fr, buffer, bufferOffset);
    // Serialize message field [Angel_motor_rr]
    bufferOffset = _serializer.float32(obj.Angel_motor_rr, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type basecontrol
    let len;
    let data = new basecontrol(null);
    // Deserialize message field [Vel_motor_fl]
    data.Vel_motor_fl = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [Vel_motor_rl]
    data.Vel_motor_rl = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [Vel_motor_fr]
    data.Vel_motor_fr = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [Vel_motor_rr]
    data.Vel_motor_rr = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [Angel_motor_fl]
    data.Angel_motor_fl = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [Angel_motor_rl]
    data.Angel_motor_rl = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [Angel_motor_fr]
    data.Angel_motor_fr = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [Angel_motor_rr]
    data.Angel_motor_rr = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 32;
  }

  static datatype() {
    // Returns string type for a message object
    return 'base_control/basecontrol';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e6029c42756a83d615f195bf059d99fc';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float32 Vel_motor_fl
    float32 Vel_motor_rl
    float32 Vel_motor_fr
    float32 Vel_motor_rr
    float32 Angel_motor_fl
    float32 Angel_motor_rl
    float32 Angel_motor_fr
    float32 Angel_motor_rr
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new basecontrol(null);
    if (msg.Vel_motor_fl !== undefined) {
      resolved.Vel_motor_fl = msg.Vel_motor_fl;
    }
    else {
      resolved.Vel_motor_fl = 0.0
    }

    if (msg.Vel_motor_rl !== undefined) {
      resolved.Vel_motor_rl = msg.Vel_motor_rl;
    }
    else {
      resolved.Vel_motor_rl = 0.0
    }

    if (msg.Vel_motor_fr !== undefined) {
      resolved.Vel_motor_fr = msg.Vel_motor_fr;
    }
    else {
      resolved.Vel_motor_fr = 0.0
    }

    if (msg.Vel_motor_rr !== undefined) {
      resolved.Vel_motor_rr = msg.Vel_motor_rr;
    }
    else {
      resolved.Vel_motor_rr = 0.0
    }

    if (msg.Angel_motor_fl !== undefined) {
      resolved.Angel_motor_fl = msg.Angel_motor_fl;
    }
    else {
      resolved.Angel_motor_fl = 0.0
    }

    if (msg.Angel_motor_rl !== undefined) {
      resolved.Angel_motor_rl = msg.Angel_motor_rl;
    }
    else {
      resolved.Angel_motor_rl = 0.0
    }

    if (msg.Angel_motor_fr !== undefined) {
      resolved.Angel_motor_fr = msg.Angel_motor_fr;
    }
    else {
      resolved.Angel_motor_fr = 0.0
    }

    if (msg.Angel_motor_rr !== undefined) {
      resolved.Angel_motor_rr = msg.Angel_motor_rr;
    }
    else {
      resolved.Angel_motor_rr = 0.0
    }

    return resolved;
    }
};

module.exports = basecontrol;
