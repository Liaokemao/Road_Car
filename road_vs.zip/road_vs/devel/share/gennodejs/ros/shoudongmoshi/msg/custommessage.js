// Auto-generated. Do not edit!

// (in-package shoudongmoshi.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class custommessage {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.ZA = null;
      this.coords = null;
      this.kuandu = null;
      this.kaicao = null;
      this.ZE = null;
    }
    else {
      if (initObj.hasOwnProperty('ZA')) {
        this.ZA = initObj.ZA
      }
      else {
        this.ZA = '';
      }
      if (initObj.hasOwnProperty('coords')) {
        this.coords = initObj.coords
      }
      else {
        this.coords = [];
      }
      if (initObj.hasOwnProperty('kuandu')) {
        this.kuandu = initObj.kuandu
      }
      else {
        this.kuandu = 0.0;
      }
      if (initObj.hasOwnProperty('kaicao')) {
        this.kaicao = initObj.kaicao
      }
      else {
        this.kaicao = 0.0;
      }
      if (initObj.hasOwnProperty('ZE')) {
        this.ZE = initObj.ZE
      }
      else {
        this.ZE = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type custommessage
    // Serialize message field [ZA]
    bufferOffset = _serializer.string(obj.ZA, buffer, bufferOffset);
    // Serialize message field [coords]
    bufferOffset = _arraySerializer.float32(obj.coords, buffer, bufferOffset, null);
    // Serialize message field [kuandu]
    bufferOffset = _serializer.float32(obj.kuandu, buffer, bufferOffset);
    // Serialize message field [kaicao]
    bufferOffset = _serializer.float32(obj.kaicao, buffer, bufferOffset);
    // Serialize message field [ZE]
    bufferOffset = _serializer.string(obj.ZE, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type custommessage
    let len;
    let data = new custommessage(null);
    // Deserialize message field [ZA]
    data.ZA = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [coords]
    data.coords = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [kuandu]
    data.kuandu = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [kaicao]
    data.kaicao = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [ZE]
    data.ZE = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.ZA);
    length += 4 * object.coords.length;
    length += _getByteLength(object.ZE);
    return length + 20;
  }

  static datatype() {
    // Returns string type for a message object
    return 'shoudongmoshi/custommessage';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '36b9b779c98bb414deea53e4a2cfcb20';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string ZA
    float32[] coords
    float32 kuandu
    float32 kaicao
    string ZE
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new custommessage(null);
    if (msg.ZA !== undefined) {
      resolved.ZA = msg.ZA;
    }
    else {
      resolved.ZA = ''
    }

    if (msg.coords !== undefined) {
      resolved.coords = msg.coords;
    }
    else {
      resolved.coords = []
    }

    if (msg.kuandu !== undefined) {
      resolved.kuandu = msg.kuandu;
    }
    else {
      resolved.kuandu = 0.0
    }

    if (msg.kaicao !== undefined) {
      resolved.kaicao = msg.kaicao;
    }
    else {
      resolved.kaicao = 0.0
    }

    if (msg.ZE !== undefined) {
      resolved.ZE = msg.ZE;
    }
    else {
      resolved.ZE = ''
    }

    return resolved;
    }
};

module.exports = custommessage;
