
"use strict";

let custommessage = require('./custommessage.js');

module.exports = {
  custommessage: custommessage,
};
