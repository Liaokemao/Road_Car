
"use strict";

let GPSStatus = require('./GPSStatus.js');
let GPSFix = require('./GPSFix.js');

module.exports = {
  GPSStatus: GPSStatus,
  GPSFix: GPSFix,
};
