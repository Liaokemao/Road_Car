// Auto-generated. Do not edit!

// (in-package operating_ctrl.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class bufeng {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.bufeng_x_motor_angle = null;
      this.bufeng_theta_motor_angle = null;
    }
    else {
      if (initObj.hasOwnProperty('bufeng_x_motor_angle')) {
        this.bufeng_x_motor_angle = initObj.bufeng_x_motor_angle
      }
      else {
        this.bufeng_x_motor_angle = 0.0;
      }
      if (initObj.hasOwnProperty('bufeng_theta_motor_angle')) {
        this.bufeng_theta_motor_angle = initObj.bufeng_theta_motor_angle
      }
      else {
        this.bufeng_theta_motor_angle = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type bufeng
    // Serialize message field [bufeng_x_motor_angle]
    bufferOffset = _serializer.float32(obj.bufeng_x_motor_angle, buffer, bufferOffset);
    // Serialize message field [bufeng_theta_motor_angle]
    bufferOffset = _serializer.float32(obj.bufeng_theta_motor_angle, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type bufeng
    let len;
    let data = new bufeng(null);
    // Deserialize message field [bufeng_x_motor_angle]
    data.bufeng_x_motor_angle = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [bufeng_theta_motor_angle]
    data.bufeng_theta_motor_angle = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'operating_ctrl/bufeng';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5b17a42db03ddb0abbc5a4af2a2cff7f';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float32 bufeng_x_motor_angle
    float32 bufeng_theta_motor_angle
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new bufeng(null);
    if (msg.bufeng_x_motor_angle !== undefined) {
      resolved.bufeng_x_motor_angle = msg.bufeng_x_motor_angle;
    }
    else {
      resolved.bufeng_x_motor_angle = 0.0
    }

    if (msg.bufeng_theta_motor_angle !== undefined) {
      resolved.bufeng_theta_motor_angle = msg.bufeng_theta_motor_angle;
    }
    else {
      resolved.bufeng_theta_motor_angle = 0.0
    }

    return resolved;
    }
};

module.exports = bufeng;
