
"use strict";

let custommessage = require('./custommessage.js');
let bufeng = require('./bufeng.js');
let kaicao = require('./kaicao.js');
let operating = require('./operating.js');
let y = require('./y.js');

module.exports = {
  custommessage: custommessage,
  bufeng: bufeng,
  kaicao: kaicao,
  operating: operating,
  y: y,
};
