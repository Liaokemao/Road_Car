#include "ros/ros.h"
#include "global_camera_pub/zhuitong.h" // 根据你的实际包名修改

int main(int argc, char **argv) 
{
    ros::init(argc, argv, "zhuitong_publisher");
    ros::NodeHandle nh;

    ros::Publisher zhuitong_pub = nh.advertise<global_camera_pub::zhuitong>("/zhuitong_pos", 10);

    ros::Rate loop_rate(1); // 设置发布频率为1Hz

    while (ros::ok()) 
    {
        global_camera_pub::zhuitong msg;

        // 假设四个点的经纬度和海拔数据
        double zhuitong1_latitude = 30.0; // 第一个点的纬度
        double zhuitong1_longitude = 40.0; // 第一个点的经度
        double zhuitong2_latitude = 35.0; // 第二个点的纬度
        double zhuitong2_longitude = 45.0; // 第二个点的经度
        double zhuitong3_latitude = 32.0; // 第三个点的纬度
        double zhuitong3_longitude = 38.0; // 第三个点的经度
        double zhuitong4_latitude = 33.0; // 第四个点的纬度
        double zhuitong4_longitude = 42.0; // 第四个点的经度

        msg.zhuitong1_latitude = zhuitong1_latitude;
        msg.zhuitong1_longitude = zhuitong1_longitude;

        zhuitong_pub.publish(msg);
        ros::Duration(1.0).sleep(); // 发布一个点后暂停1秒

        msg.zhuitong2_latitude = zhuitong2_latitude;
        msg.zhuitong2_longitude = zhuitong2_longitude;

        zhuitong_pub.publish(msg);
        ros::Duration(1.0).sleep();

        msg.zhuitong3_latitude = zhuitong3_latitude;
        msg.zhuitong3_longitude = zhuitong3_longitude;

        zhuitong_pub.publish(msg);
        ros::Duration(1.0).sleep();

        msg.zhuitong4_latitude = zhuitong4_latitude;
        msg.zhuitong4_longitude = zhuitong4_longitude;

        zhuitong_pub.publish(msg);
        ros::Duration(1.0).sleep();

        ros::spinOnce();
        loop_rate.sleep();
    }

    return 0;
}
