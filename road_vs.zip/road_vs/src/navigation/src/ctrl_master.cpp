/*
***************程序说明***************
本程序为ros节点管理中心，负责检测小车当前所处模式，实现模式切换
*/
#include "ros/ros.h"
#include "std_msgs/Int32.h"

double current_mode = -1; // 设置初始值，其中0为手动模式，1为导航模式，2为扫描模式，3为作业模式,4为牵引模式；
int fangxianghuizheng = 0;//设置1方向回正
double local_cam_ctrl_pub_rate=1;//扫描模式发布频率
double y_ctrl_pub_rate= 1;//Y轴控制发布频率
double operating_pub_rate=1;//作业模式插补算法发布频率
double kaicao_pub_rate=1;//开槽发布频率
double kaicao_z_angle=1;//开槽下降高度1
double bufeng_pub_rate=1;//补缝发布频率
double bufeng_z_angle=1;//开槽下降高度
double now_is_kaicao_bufeng=0;//开槽/补缝执行逻辑
int temperature=10;
int zuoye_mode = 0;
int kaicao_bufeng = 0;
int kaicao_step = 0;
int bufeng_step = 0;
int only_kaicao_or_bufeng = -1;
double T = 0.02;//1/50;采样频率，发布话题的频率为50HZ
double distance_threshold = 0.1; // 设置一个距离阈值，可以根据实际情况调整
double distance_angle = 0.2;
double zhongliang = 0;
//pid控制器参数设置
//航向控制参数设置
double k=1;
double ki=0.0001;
double kd=0.001;
double k2=0.05;
double ki2=0.001;
double kd2=0.01;
double cmd_vel_rate=4.0;
double control_topic_rate=1000.0;
int shebei1 = -1;
int shebei2 = -1;
int shebei3 = -1;
int shebei4 = -1;
int shebei5 = -1;
int shebei6 = -1;
int temperature_work = 3;//1为工作，2为不工作
int now_is_record = 0;
double liefeng_length = 0;
double liefeng_width = 0;
int shifoukaicao = 0;
int shutdown = 0;
int dianziweilan_up = 0;
int dianziweilan_down = 0;
int dianziweilan_left = 0;
int dianziweilan_right = 0;
int chaochufanwei = 0;
int wuliefeng = 0;
int zhaodaoliefeng = 0;
int crack_capture = -1;
double first_kaicao_x = 0;
double first_bufeng_x = 0;
double first_y = 0;
int main(int argc, char **argv) 
{
    ros::init(argc, argv, "ctrl_master");
    ros::NodeHandle nh;
    /******************模式切换参数******************/
    ros::param::set("/current_mode", current_mode); // 将 current_mode 设置为全局参数并挂载到ROS参数服务器上：0，1，2，3
    ros::param::set("/fangxianghuizheng", fangxianghuizheng);
    /******************作业插补算法的参数******************/
    ros::param::set("/operating_pub_rate", operating_pub_rate);
    /******************串行作业的参数******************/
    ros::param::set("/zuoye_mode", zuoye_mode); // 将 zuoye_mode 设置为全局参数并挂载到ROS参数服务器上：1/2
    ros::param::set("/kaicao_bufeng", kaicao_bufeng); // 将 kaicao_bufeng 设置为全局参数并挂载到ROS参数服务器上：0/1
    /******************Y轴控制的参数******************/
    ros::param::set("/y_ctrl_pub_rate", y_ctrl_pub_rate); 
    /******************开槽控制的参数******************/
    ros::param::set("/kaicao_pub_rate", kaicao_pub_rate); 
    ros::param::set("/kaicao_z_angle", kaicao_z_angle);
    ros::param::set("/now_is_kaicao_bufeng", now_is_kaicao_bufeng);    
    ros::param::set("/kaicao_step", kaicao_step);  
    ros::param::set("/only_kaicao_or_bufeng", only_kaicao_or_bufeng);  
    /******************补缝控制的参数******************/
    ros::param::set("/bufeng_pub_rate", bufeng_pub_rate); 
    ros::param::set("/bufeng_z_angle", bufeng_z_angle);
    ros::param::set("/bufeng_step", bufeng_step);
    ros::param::set("/temperature", temperature);
    /******************扫描模式的参数******************/
    ros::param::set("/local_cam_ctrl_pub_rate", local_cam_ctrl_pub_rate); 
    /******************导航模式的参数******************/
    ros::param::set("/T", T); // 采样频率，默认0.02
    ros::param::set("/distance_threshold", distance_threshold); // 到达目标的距离阈值，默认3.0
    ros::param::set("/distance_angle", distance_angle); // 到达目标的角度阈值，默认0.2
    ros::param::set("/cmd_vel_rate",cmd_vel_rate);
    ros::param::set("/control_topic_rate",control_topic_rate);
    // PID参数
    ros::param::set("/k", k);
    ros::param::set("/ki", ki);
    ros::param::set("/kd", kd);
    ros::param::set("/k2", k2);
    ros::param::set("/ki2", ki2);
    ros::param::set("/kd2", kd2);
    //IO设备参数
    ros::param::set("/shebei1", shebei1);
    ros::param::set("/shebei2", shebei2);
    ros::param::set("/shebei3", shebei3);
    ros::param::set("/shebei4", shebei4);
    ros::param::set("/shebei5", shebei5);
    ros::param::set("/shebei6", shebei6);    
    ros::param::set("/temperature_work", temperature_work);
    ros::param::set("/now_is_record", now_is_record);
    ros::param::set("/liefeng_length", liefeng_length);
    ros::param::set("/liefeng_width", liefeng_width);
    ros::param::set("/shifoukaicao", shifoukaicao);
    ros::param::set("/shutdown", shutdown);
    ros::param::set("/dianziweilan_up", dianziweilan_up);
    ros::param::set("/dianziweilan_down", dianziweilan_down);
    ros::param::set("/dianziweilan_left", dianziweilan_left);
    ros::param::set("/dianziweilan_right", dianziweilan_right);
    ros::param::set("/chaochufanwei", chaochufanwei);
    ros::param::set("/wuliefeng", wuliefeng);
    ros::param::set("/zhaodaoliefeng", zhaodaoliefeng);
    ros::param::set("/zhongliang", zhongliang);
    ros::param::set("/crack_capture",crack_capture);
    ros::param::set("/first_kaicao_x",first_kaicao_x);
    ros::param::set("/first_bufeng_x",first_bufeng_x);
    ros::param::set("/first_y",first_y);
    ros::Rate loop_rate(1);
    return 0;
}