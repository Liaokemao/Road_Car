#include <ros/ros.h>
#include <std_msgs/Float64MultiArray.h>

// 定义消息类型
struct FenceMsg {
  struct {
    double x;
    double y;
  } zhuitong1, zhuitong2, zhuitong3, zhuitong4;
};

// 全局变量，用于发布zhuitong_pos话题
ros::Publisher zhuitongPosPub;

// 回调函数，用于处理接收到的电子围栏消息
void fenceCallback(const std_msgs::Float64MultiArray::ConstPtr& msg) {
  // 创建并初始化FenceMsg结构体
  FenceMsg fence;
  fence.zhuitong1.x = msg->data[0];
  fence.zhuitong1.y = msg->data[1];
  fence.zhuitong2.x = msg->data[2];
  fence.zhuitong2.y = msg->data[3];
  fence.zhuitong3.x = msg->data[4];
  fence.zhuitong3.y = msg->data[5];
  fence.zhuitong4.x = msg->data[6];
  fence.zhuitong4.y = msg->data[7];

  // 打印接收到的电子围栏信息
  ROS_INFO("Received Fence Info:\n"
           "Zhuitong1: (%f, %f)\n"
           "Zhuitong2: (%f, %f)\n"
           "Zhuitong3: (%f, %f)\n"
           "Zhuitong4: (%f, %f)",
           fence.zhuitong1.x, fence.zhuitong1.y,
           fence.zhuitong2.x, fence.zhuitong2.y,
           fence.zhuitong3.x, fence.zhuitong3.y,
           fence.zhuitong4.x, fence.zhuitong4.y);

  // 在这里可以根据需要进行后续处理

  // 发布zhuitong_pos话题
  std_msgs::Float64MultiArray zhuitongPosMsg;
  zhuitongPosMsg.data.push_back(fence.zhuitong1.x);
  zhuitongPosMsg.data.push_back(fence.zhuitong1.y);
  zhuitongPosMsg.data.push_back(fence.zhuitong2.x);
  zhuitongPosMsg.data.push_back(fence.zhuitong2.y);
  zhuitongPosMsg.data.push_back(fence.zhuitong3.x);
  zhuitongPosMsg.data.push_back(fence.zhuitong3.y);
  zhuitongPosMsg.data.push_back(fence.zhuitong4.x);
  zhuitongPosMsg.data.push_back(fence.zhuitong4.y);

  zhuitongPosPub.publish(zhuitongPosMsg);
}

int main(int argc, char** argv) {
  // 初始化ROS节点
  ros::init(argc, argv, "dianziweilan");

  // 创建节点句柄
  ros::NodeHandle nh;

  // 订阅电子围栏话题，指定回调函数
  ros::Subscriber fenceSub = nh.subscribe("dianziweilan", 10, fenceCallback);

  // 创建发布器，发布zhuitong_pos话题
  zhuitongPosPub = nh.advertise<std_msgs::Float64MultiArray>("zhuitong_pos", 10);

  // 循环等待ROS事件
  ros::spin();

  return 0;
}
