/*
***************程序说明***************
本程序导航模式，根据导航节点提供的目标位置，融合GPS，IMU传感器消息，利用PID算法对底盘角速度进行控制，并判断小车是否到达目标位置
程序实现步骤: 1.void targetPositionCallback（）获取目标位置
            2.gpsInfoCallback（）获取GPS消息
            3.imuInfoCallback（）获取IMU
            4.pidCallback（）pid计算线速度，角速度
            5.int main（）ros主函数
*/
#include <ros/ros.h>
#include "sensor_msgs/Imu.h"
#include "sensor_msgs/NavSatFix.h"
#include "geometry_msgs/Twist.h"
#include <math.h>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2/LinearMath/Matrix3x3.h>
#include "std_msgs/Float64MultiArray.h"
#include <nav_msgs/Odometry.h>

using namespace std;
/*****初始位置姿态设置和目标点设置*****/
//起始坐标
double current_x=0;
double current_y=0;
double current_x0=0;
double current_y0=0;
double current_d0=0;
double theta=0;//初始航向角
double x_goal=0;
double y_goal=0;
double d0_goal=0;
double theta_goal = 0.0;
double T = 0.1;//1/10;采样频率，发布话题的频率为50HZ
double distance_threshold = 0.1; // 设置一个距离阈值，可以根据实际情况调整
double distance_angle = 0.2;
//pid控制器参数设置
//航向控制参数设置
double k=1;
double ki=0.0001;
double kd=0.001;
double error_sum=0;
double pre_error=0;
double k2=0.05;
double ki2=0.001;
double kd2=0.01;
double error_sum2=0;
double pre_error2=0;
double angle_error2=0;
double distance_to_goal;
double cmd_vel_rate = 10; // 默认值为10 Hz
bool isInitized=false;
bool zhuanxiangjieshu = false;
bool yuandizhuanxiang = false;
double w;
double v_x;
double v_y;
double mode;
ros::Publisher Twist_info_pub; 
/*
**************函数说明**************
1.接收话题target_position消息
*/
void targetPositionCallback(const std_msgs::Float64MultiArray::ConstPtr& msg) 
{
    ros::NodeHandle nh;
    x_goal = msg->data[0];
    y_goal = msg->data[1];
    ROS_INFO("X_GOAL: %f", x_goal);
    ROS_INFO("y_GOAL: %f", y_goal);
    theta_goal = msg->data[2]; // 确保 msg->data 至少包含 3 个元素，否则可能引发错误
    zhuanxiangjieshu = false;
    yuandizhuanxiang = false;    
    nh.setParam("/current_mode", 1.5);
}

/*
**************函数说明**************
1.接收GPS中小车定位消息
*/
void gpsInfoCallback(const nav_msgs::Odometry::ConstPtr& msg)
{
    ros::NodeHandle nh;  
    current_x = msg->pose.pose.position.x; // 获取经度
    current_y = msg->pose.pose.position.y; // 获取纬度
    nh.getParam("/current_mode", mode);  
    if(mode==1)
    {
        current_x0 = current_x;
        current_y0 = current_y;
    }

}
/*
**************函数说明**************
1.接收IMU中小车航向角消息
*/
void imuInfoCallback(const sensor_msgs::Imu::ConstPtr& msg) 
{
    double qw = msg->orientation.w;
    double qx = msg->orientation.x;
    double qy = msg->orientation.y;
    double qz = msg->orientation.z;

    tf2::Quaternion quat(qx, qy, qz, qw);
    tf2::Matrix3x3 mat(quat);
    double roll, pitch, yaw;
    mat.getRPY(roll, pitch, yaw);
    double theta2 = yaw * 180 / M_PI; // 将弧度转换为角度
    ROS_INFO("theta = %f degrees", theta2); // 打印输出角度
    theta = yaw;
    //ROS_INFO("theta = %f", theta);
}

/*
**************函数说明**************
1.初始化ROS节点句柄
2.订阅target_position，YOUR_ODOM_TOPIC，imu_data话题
3.发布cmd_vel话题
4.判断当前是否到达目标位置
5.判断当前是否到达目标姿态
6.发布线速度，角速度命令
*/
int main(int argc, char **argv)
{
    //1.初始化ROS节点句柄
    ROS_INFO("now_path_plan");
    ros::init(argc, argv, "path_plan");
    ros::NodeHandle nh;
    // 从参数服务器获取或设置默认值
    nh.param("/T", T, 0.02); // 采样频率，默认0.02
    nh.param("/distance_threshold", distance_threshold, 0.1); // 到达目标的距离阈值，默认3.0
    nh.param("/distance_angle", distance_angle, 0.2); // 到达目标的角度阈值，默认0.2
    // PID参数
    nh.param("/k", k, 1.0);
    nh.param("/ki", ki, 0.0001);
    nh.param("/kd", kd, 0.001);
    nh.param("/k2", k2, 0.05);
    nh.param("/ki2", ki2, 0.001);
    nh.param("/kd2", kd2, 0.01);
    nh.param("/cmd_vel_rate", cmd_vel_rate, 4.0);
    ros::Subscriber target_position_sub = nh.subscribe<std_msgs::Float64MultiArray>("/target_position", 100, targetPositionCallback);
    ros::Subscriber fix_sub = nh.subscribe<nav_msgs::Odometry>("/YOUR_ODOM_TOPIC", 100000, gpsInfoCallback);
    ros::Subscriber imu_sub = nh.subscribe<sensor_msgs::Imu>("/imu_data", 100000, imuInfoCallback);

    //3.发布cmd_vel话题
    Twist_info_pub = nh.advertise<geometry_msgs::Twist>("/auto_cmd_vel", 10000);
    ros::Rate loop_rate(cmd_vel_rate); // 使用ros::Rate对象来控制循环频率
while (ros::ok()) 
{
    double current_mode;
    nh.getParam("/current_mode", current_mode);

    if (current_mode == 1.5) 
    {
        current_d0 = sqrt(pow((current_x - current_x0), 2) + pow((current_y - current_y0), 2));
        d0_goal = sqrt(pow((x_goal), 2) + pow((y_goal), 2));
        distance_to_goal = d0_goal - current_d0;
        ROS_INFO("current_d0: %f", current_d0);
        ROS_INFO("d0_goal: %f", d0_goal);
        ROS_INFO("Distance to Goal: %f", distance_to_goal);
        if (distance_to_goal < 0.1) 
        {
            double target_angle = theta_goal; // 设置目标角度
            double angle_error2 = target_angle - theta ; // 计算角度误差
            ROS_INFO("ANGLE to Goal: %f", angle_error2);

            // 检查是否到达目标姿态
            if (fabs(angle_error2) < 0.05) 
            {
                int new_mode = 10;
                nh.setParam("/current_mode", new_mode);

                // 发布停止命令
                geometry_msgs::Twist stop_cmd_vel;
                stop_cmd_vel.angular.z = 0.0;
                stop_cmd_vel.linear.x = 0.0;
                stop_cmd_vel.linear.y = 0.0;
                Twist_info_pub.publish(stop_cmd_vel);
                
            } 
            else 
            {
                // 使用 PID 控制发布 vel_pub
                if(angle_error2 > 0 )
                {
                    w = 1;
                }else if(angle_error2 < 0 )
                {
                    w = -1;
                }
                v_x = 0.0;
                v_y = 0.0;
                if(!yuandizhuanxiang){
                geometry_msgs::Twist vel_pub;  
                vel_pub.angular.z = 1;  
                vel_pub.linear.x = 0.002;  // 几乎为0的线性速度  
                vel_pub.linear.y = 0;  
                Twist_info_pub.publish(vel_pub);   
                ros::Duration(3).sleep();  
                yuandizhuanxiang = true;           
                }
                // 发布线速度，角速度命令
                geometry_msgs::Twist vel_pub;
                vel_pub.angular.z = w;
                vel_pub.linear.x = v_x;
                vel_pub.linear.y = v_y;
                Twist_info_pub.publish(vel_pub);
            }
        } 
        else 
        {
            double theta_error1;
            double theta_error0 = atan2(y_goal,  x_goal);
            ROS_INFO("theta_error0: %f", theta_error0);
            double theta_gap = abs( (M_PI / 2) - abs(theta_error0));
            ROS_INFO("theta_gap: %f", theta_gap);
            if (theta_gap > 0.1 && theta_error0 < (M_PI / 2))
            {
                theta_error1 = -1 *(M_PI /2 - theta_error0);
            }else if (theta_error0 > (M_PI / 2))
            {
                theta_error1 = (theta_error0 - M_PI/2);
            }else if(theta_gap <= 0.1)
            {
                theta_error1 = 0;
            }
            double v = 2; 
            v_x = v;
            w = theta_error1;
            if(!zhuanxiangjieshu){
                geometry_msgs::Twist vel_pub;  
                vel_pub.angular.z = w;  
                vel_pub.linear.x = 0.001;  // 几乎为0的线性速度  
                vel_pub.linear.y = 0;  
                Twist_info_pub.publish(vel_pub);   
                ros::Duration(3).sleep();  
                zhuanxiangjieshu = true;           
            }
            // 在这里继续发布 cmd_vel 命令
            geometry_msgs::Twist vel_pub;
            vel_pub.angular.z = w;
            vel_pub.linear.x = v_x;
            vel_pub.linear.y = 0;
            Twist_info_pub.publish(vel_pub);
        }
    }

    ros::spinOnce(); // 处理回调函数
    loop_rate.sleep(); // 控制循环频率
}



    return 0;
}