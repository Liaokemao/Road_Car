/*
***************程序说明***************
本程序导航模式，根据全局相机提供的裂缝消息和锥桶消息，IMU消息，判断目标位置是否会超出电子围栏，
程序实现步骤: 1.void bpositionCallback（）获取目标位置
            2.fixCallback（）获取GPS消息
            3.zhuitongCallback（）获取锥桶消息
            4.calculateTarget（）判断是否超出电子围栏
            5.int main（）ros主函数
*/
#include "ros/ros.h"
#include "std_msgs/String.h"
#include <sensor_msgs/Imu.h>
#include <sensor_msgs/NavSatFix.h> // 包含 gps_common 的 fix 消息
#include <tf2/LinearMath/Quaternion.h>
#include <tf2/LinearMath/Matrix3x3.h>
#include "std_msgs/Float64.h"
#include <iostream>
#include <cmath>
#include "std_msgs/Float64MultiArray.h"
#include <nav_msgs/Odometry.h>

double L = 2.6;  // 小车长度
double D = 2; //小车宽度
double car_x = 0.0;
double car_y = 0.0;
double car_z = 0.0;
double global_cam_x0=0.0;
double global_cam_y0=0.0;
double global_cam_theta0=0.0;
double global_cam_edge0 =0;
double prev_y_max = 0.0;
double prev_y_min = 0.0;
double prev_x_min = 0.0;
double prev_x_max = 0.0;
double x_min=0;
double y_min=0;
double x_max=0;
double y_max=0;
double target_x=0;
double target_y=0;
double target_theta=0;
double current_x=0;
double current_y=0;
double temp_x=0;
double temp_y=0;
bool is_valid_position;
ros::Publisher target_position_pub;

/*
**************函数说明**************
1.接收话题global_position 消息
*/

/*
**************函数说明**************
1.处理来自 锥桶 的 fix 消息
2.计算电子围栏范围
*/
void calculateTarget()
{
    ros::NodeHandle nh;
    if (global_cam_x0 <= 0)
    {
        temp_x = abs(global_cam_x0)  + L / 2 - current_x;
        temp_y = global_cam_y0  + D / 2 + current_y;
        // 2.判断目标位置是否超出电子围栏
        // 3.得出最终导航位置
        bool is_valid_position = true;
        if (temp_x < (x_min))
        {
            target_x = global_cam_x0;
            ROS_INFO("Target x: %f", target_x);
        }else if (temp_x >= x_min)
        {
            ROS_INFO("Target Position is outside the x_range");
            nh.setParam("/current_mode", 0);
            nh.setParam("/chaochufanwei", 1);
            is_valid_position = false;
        }
        
        if (temp_y < (y_max))
        {
            target_y = global_cam_y0;
            ROS_INFO("Target y: %f", target_y);
        }else if (temp_y >= (y_max))
        {
            ROS_INFO("Target Position is outside the y_range");
            nh.setParam("/current_mode", 0);
            nh.setParam("/chaochufanwei", 1);
            is_valid_position = false;
        }
    }else if (global_cam_x0 > 0)
    {
        temp_x = global_cam_x0  + L / 2 + current_x;
        temp_y = global_cam_y0  + D / 2 + current_y;
        // 2.判断目标位置是否超出电子围栏
        // 3.得出最终导航位置
        bool is_valid_position = true;
        if (temp_x < (x_max))
        {
            target_x = global_cam_x0;
            ROS_INFO("Target x: %f", target_x);
        }else if (temp_x >=  x_max)
        {
            ROS_INFO("Target Position is outside the x_range");
            nh.setParam("/current_mode", 0);
            nh.setParam("/chaochufanwei", 1);
            is_valid_position = false;
        }
        
        if (temp_y < (y_max))
        {
            target_y = global_cam_y0;
            ROS_INFO("Target y: %f", target_y);
        }else if (temp_y >= (y_max))
        {
            ROS_INFO("Target Position is outside the y_range");
            nh.setParam("/current_mode", 0);
            nh.setParam("/chaochufanwei", 1);
            is_valid_position = false;
        }
    }
    target_theta = global_cam_theta0;
    // 4.创建话题发布导航位置target_position
    if (is_valid_position)
    {
        std_msgs::Float64MultiArray target_msg;
        target_msg.data.push_back(target_x);
        target_msg.data.push_back(target_y);
        target_msg.data.push_back(target_theta);
        target_position_pub.publish(target_msg);
    }
    current_x += global_cam_x0;
    current_y += global_cam_y0;
}

/*
**************函数说明**************
1.接收GPS中小车定位消息
*/
void positionCallback(const std_msgs::String::ConstPtr& msg) 
{
    // 检查消息是否以 "GA," 开头
    if (msg->data.find("GA,") == 0)
    {
        // 从消息中解析出车辆位置信息
        std::istringstream iss(msg->data.substr(3)); // 跳过 "GA,"
        float x_center, y_center, xuanzhuan_angle, edge;
        char delimiter;
        iss >> x_center >> delimiter >> y_center >> delimiter >> xuanzhuan_angle >> delimiter >> edge;
        // 记录车辆位置信息
        global_cam_x0 = x_center / 1000;
        global_cam_y0 = y_center / 1000;
        global_cam_theta0 = xuanzhuan_angle;
        global_cam_edge0 = edge;
        ROS_INFO("x_center: %.2f, y_center: %.2f, xuanzhuan_angle: %.2f, edge: %.2f", x_center, y_center, xuanzhuan_angle, edge);
        calculateTarget();
    }
}
/*
**************函数说明**************
1.计算导航目标的绝对位置
2.判断目标位置是否超出电子围栏
3.得出最终导航位置
4.创建话题发布导航位置target_position
*/

/*
**************函数说明**************
1.初始化ROS节点句柄
2.订阅global_position，YOUR_ODOM_TOPIC，zhuitong_pos话题
3.发布target_position话题
4.target_opsition_publish_rate挂载参数服务器
*/
int main(int argc, char** argv) 
{
    //1.初始化ROS节点句柄
    ros::init(argc, argv, "navigation");
    ros::NodeHandle nh;
    //2.订阅global_position，YOUR_ODOM_TOPIC，zhuitong_pos话题
    ros::Subscriber sub = nh.subscribe("car_position", 10, positionCallback);
    //3.发布target_position话题
    target_position_pub = nh.advertise<std_msgs::Float64MultiArray>("/target_position", 10);
    //4.target_opsition_publish_rate挂载参数服务器
    int publish_rate;
    nh.param<int>("/target_opsition_publish_rate", publish_rate, 1);
    ros::Rate loop_rate(publish_rate); // 使用从参数服务器获取的发布频率
    while (ros::ok()) {
        nh.getParam("/dianziweilan_up", y_max);
        nh.getParam("/dianziweilan_down", y_min);
        nh.getParam("/dianziweilan_left", x_min);
        nh.getParam("/dianziweilan_right", x_max);
        if (y_max != prev_y_max || y_min != prev_y_min || x_min != prev_x_min || x_max != prev_x_max) 
        {
            // 更新上一次参数的值
            prev_y_max = y_max;
            prev_y_min = y_min;
            prev_x_min = x_min;
            prev_x_max = x_max;
        }
        ros::spinOnce();
    }
    return 0;
}