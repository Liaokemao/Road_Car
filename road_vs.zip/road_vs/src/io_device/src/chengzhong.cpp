#include <ros/ros.h>
#include <iostream>
#include <modbus.h>
#include <cstring>
#include <vector>
#include <thread>
#include <chrono>
double zhongliang = 0;
// 1. 查询输入端口状态
void printSwitchStates(modbus_t* ctx) {
    ros::NodeHandle nh;
    int rc;
    uint8_t query[64]; // 存储发送的查询命令
    uint8_t read_buffer[64]; // 读取的数据缓冲区
    query[0] = 0x01; // 设备地址
    query[1] = 0x03; // 功能码
    query[2] = 0x00; // 寄存器地址高位
    query[3] = 0x00; // 寄存器地址低位
    query[4] = 0x00; // 读取数量高位
    query[5] = 0x01; // 读取数量低位

    // 发送查询命令
    rc = modbus_send_raw_request(ctx, query, 6);
    if (rc == -1) {
        std::cerr << "发送Modbus命令失败: " << modbus_strerror(errno) << "\n";
        return;
    }

    // 读取响应数据
    rc = modbus_receive_confirmation(ctx, read_buffer);
    if (rc == -1) {
        std::cerr << "读取响应数据失败: " << modbus_strerror(errno) << "\n";
        return;
    }

    // 解析响应数据
    if (read_buffer[1] != 0x03 || read_buffer[2] != 2) {
        std::cerr << "错误的响应数据\n";
        return;
    }

    // 提取有符号寄存器值并转换为十进制
    int16_t value = (read_buffer[3] << 8) | read_buffer[4];
    //std::cout << "解析得到的有符号值为：" << value << std::endl;
    double zhongliang = value * 0.1;
    std::stringstream ss;
    ss << std::fixed << std::setprecision(1) << zhongliang;
    nh.setParam("/zhongliang", ss.str());
    ros::param::set("/zhongliang", zhongliang);
}




int main(int argc, char** argv) {
    // 初始化ROS节点
    ros::init(argc, argv, "chengzhong");
    ros::NodeHandle nh;
    modbus_t* ctx;
    int rc;
    uint8_t query[64]; // 存储发送的查询命令
    uint8_t read_buffer[MODBUS_MAX_READ_BITS]; // 读取的数据缓冲区
    uint16_t write_data[9]; // 写入的数据缓冲区

    // 创建Modbus RTU的上下文
    ctx = modbus_new_rtu("/dev/ttyUSB5", 9600, 'N', 8, 1);
    if (ctx == NULL) {
        std::cerr << "无法创建Modbus上下文\n";
        return 1;
    }
    modbus_set_slave(ctx, 0x01);
    // 连接Modbus从设备

    // 尝试连接Modbus从设备，一直重试直到连接成功
    while (true) {
        if (modbus_connect(ctx) == -1) {
            //std::cerr << "连接失败: " << modbus_strerror(errno) << "\n";
            //std::cerr << "尝试重新连接...\n";
            std::this_thread::sleep_for(std::chrono::seconds(5));  // 等待1秒再尝试
        } else {
            std::cout << "成功连接到Modbus从设备\n";
            break;  // 连接成功，跳出循环
        }
    }



    while (ros::ok()) {
        printSwitchStates(ctx);  // 调用函数打印输入端口状态
        std::this_thread::sleep_for(std::chrono::seconds(1));  // 每秒执行一次
    }        


    return 0;
}
