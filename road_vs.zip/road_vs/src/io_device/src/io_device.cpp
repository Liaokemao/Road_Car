#include <ros/ros.h>
#include <iostream>
#include <modbus.h>
#include <cstring>
#include <vector>
#include <thread>
#include <chrono>
// 1. 查询输入端口状态
void printSwitchStates(modbus_t* ctx) {
    int rc;
    uint8_t query[64]; // 存储发送的查询命令
    uint8_t read_buffer[64]; // 读取的数据缓冲区

    // 构建查询输入端口状态的Modbus命令
    /*
    如一次查询 4 个端口发送：01 02 27 11 00 04 23 78
    收到数据：01 02 01 04 A0 4B
    发送协议中，2711 表示地址，00 04 表示读 4 个数据
    返回数量中，04 表示第 3 路有开关输入（如 03 表示第 1 和第 2 路都有输入
    */
    query[0] = 0x01; // 设备地址
    query[1] = 0x02; // 功能码
    query[2] = 0x27; // 寄存器地址高位
    query[3] = 0x11; // 寄存器地址低位
    query[4] = 0x00; // 读取数量高位
    query[5] = 0x04; // 读取数量低位

    // 发送查询命令
    rc = modbus_send_raw_request(ctx, query, 6);
    if (rc == -1) {
        std::cerr << "发送Modbus命令失败: " << modbus_strerror(errno) << "\n";
        return;
    }

    // 读取响应数据
    rc = modbus_receive_confirmation(ctx, read_buffer);
    if (rc == -1) {
        std::cerr << "读取响应数据失败: " << modbus_strerror(errno) << "\n";
        return;
    }

    // 解析响应数据
    // 假设每个字节代表一个开关状态
    for (int i = 0; i < rc; ++i) {
        for (int j = 0; j < 8; ++j) {
            uint8_t switch_state = (read_buffer[i] >> j) & 0x01;
            std::cout << "开关 " << i * 8 + j + 1 << " 状态: " << (switch_state ? "开" : "关") << std::endl;
        }
    }
}
// 2. 查询12路输出端口状态
// 读取输出端口状态的函数
void readOutputPortStatus(modbus_t* ctx) {
    int rc;
    uint8_t query[6]; // 存储发送的查询命令
    uint8_t read_buffer[64]; // 读取的数据缓冲区

    // 构建查询输出端口状态的Modbus命令
    query[0] = 0x01; // 设备地址
    query[1] = 0x01; // 功能码
    query[2] = 0x00; // 寄存器地址高位
    query[3] = 0x01; // 寄存器地址低位
    query[4] = 0x00; // 读取数量高位
    query[5] = 0x04; // 读取数量低位

    // 发送查询命令
    rc = modbus_send_raw_request(ctx, query, 6);
    if (rc == -1) {
        std::cerr << "发送Modbus命令失败: " <<modbus_strerror(errno) << "\n";
        modbus_close(ctx);
        modbus_free(ctx);
        exit(1);
    }

    // 读取响应数据
    rc = modbus_receive_confirmation(ctx, read_buffer);
    if (rc == -1) {
        std::cerr << "读取响应数据失败: " << modbus_strerror(errno) << "\n";
        modbus_close(ctx);
        modbus_free(ctx);
        exit(1);
    }

    // 解析并显示输出端口状态
    for (int i = 0; i < rc; ++i) {
        for (int j = 0; j < 8; ++j) {
            uint8_t relay_state = (read_buffer[i] >> j) & 0x01;
            std::cout << "继电器 " << i * 8 + j + 1 << " 状态: " << (relay_state ? "通" : "断") << std::endl;
        }
    }
}
// 3. 控制12路输出端口状态
void printHexMessage(const uint8_t* message, int length) {
    std::cout << "Hex Message: ";
    for (int i = 0; i < length; ++i) {
        std::cout << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(message[i]) << " ";
    }
    std::cout << std::endl;
    // 
}
 // 控制输出端口状态的函数
void controlOutputPort(modbus_t* ctx, int outputNumber, bool state) {
    int rc;
    uint8_t query[6]; // 存储发送的查询命令
    uint16_t read_buffer[16]; // 读取的数据缓冲区
    // 构建控制单个线圈状态的Modbus命令
    query[0] = 0x01; // 设备地址
    query[1] = 0x05; // 控制单个线圈状态功能码
    query[2] = 0x00; // 寄存器地址高位
    query[3] = static_cast<uint8_t>(outputNumber); // 寄存器地址低位（1-12路）
    query[4] = state ? 0xFF : 0x00; // 控制状态：FF表示通，00表示断
    query[5] = 0x00; // 寄存器数量低位
    //printHexMessage(query, 6);
    // 发送控制命令
    rc = modbus_send_raw_request(ctx, query, 6);
    if (rc == -1) {
        std::cerr << "发送Modbus命令失败: " << modbus_strerror(errno) << "\n";
        modbus_close(ctx);
        modbus_free(ctx);
        exit(1);
    }

    // 如果需要读取响应数据，在这里添加相应的代码

    //std::cout << "成功发送控制命令到输出端口 " << outputNumber << "，状态：" << (state ? "通" : "断") << "\n";
}


// 4. 查询控制器版本信息
// 函数用于查询控制器版本信息
void getControllerVersion(modbus_t* ctx, char* version) {
    int rc;
    uint8_t query[6]; // 存储发送的查询命令
    uint16_t read_buffer[16]; // 读取的数据缓冲区

    // 构建查询控制器版本信息的Modbus命令
    query[0] = 0x01; // 设备地址
    query[1] = 0x04; // 读取输入寄存器功能码
    query[2] = 0x75; // 寄存器地址高位
    query[3] = 0x31; // 寄存器地址低位
    query[4] = 0x00; // 寄存器数量高位
    query[5] = 0x0E; // 寄存器数量低位
    //printHexMessage(query, 6);
    // 发送查询命令
    rc = modbus_send_raw_request(ctx, query, 6);
    if (rc == -1) {
        std::cerr << "发送Modbus命令失败: " << modbus_strerror(errno) << "\n";
        modbus_close(ctx);
        modbus_free(ctx);
        exit(1);
    }

    // 读取响应数据
    rc = modbus_receive_confirmation(ctx, reinterpret_cast<uint8_t*>(read_buffer));
    if (rc == -1) {
        std::cerr << "接收Modbus响应失败: " << modbus_strerror(errno) << "\n";
        modbus_close(ctx);
        modbus_free(ctx);
        exit(1);
    }

    // 转换响应数据为字符形式
    memcpy(version, &read_buffer[3], 30);
    version[30] = '\0'; // 添加字符串结束标志

    //std::cout << "控制器版本信息: " << version << "\n";
}
// 5. 设置ID
// 设置设备ID的函数
void setDeviceID(modbus_t* ctx, uint8_t deviceAddress, uint16_t registerAddress, uint16_t newID) {
    int rc;
    uint8_t query[11]; // 存储发送的查询命令

    // 构建设置ID的Modbus命令
    query[0] = deviceAddress;     // 设备地址
    query[1] = 0x10;              // 写入多个寄存器功能码
    query[2] = registerAddress >> 8; // 寄存器地址高位
    query[3] = registerAddress;   // 寄存器地址低位
    query[4] = 0x00;              // 寄存器数量高位
    query[5] = 0x05;              // 寄存器数量低位
    query[6] = 0x0A;              // 写入的字节计数
    query[7] = 0x00;              // 数据高位（ID设置）
    query[8] = newID;             // 数据低位（新ID）
    query[9] = 0x00;              // 数据高位（固定数据）
    query[10] = 0xCF;             // 数据低位（固定数据）
    
    // 发送设置ID的命令
    rc = modbus_send_raw_request(ctx, query, 11);
    if (rc == -1) {
        std::cerr << "发送Modbus命令失败: " << modbus_strerror(errno) << "\n";
        modbus_close(ctx);
        modbus_free(ctx);
        exit(1);
    }

    //std::cout << "成功设置新的设备ID\n";
}

// 6. 控制延时通断
   void controlDelaySwitch1(modbus_t* ctx, uint16_t mode, uint16_t channel, uint16_t delayTime, int addr) {
    int rc;
    uint16_t write_data[3]; // 写入的数据缓冲区
    
    // 设置控制延时通断的参数
    write_data[0] = mode;     // 控制器模式（01为延时断开 02为延时接通）
    write_data[1] = channel;  // 要控制的通道号（1-12任何一个数字，13表示全部通道）
    write_data[2] = delayTime; // 延时的时间单位是0.1秒（0X0A表示10*0.1=1秒）

    // 发送控制延时通断的命令
    rc = modbus_write_registers(ctx, addr, 3, write_data);
    if (rc == -1) {
        std::cerr << "发送Modbus命令失败: " << modbus_strerror(errno) << "\n";
        modbus_close(ctx);
        modbus_free(ctx);
        exit(1);
    }

    //std::cout << "成功发送控制延时通断的命令\n";
}
// 7.函数用于控制延时通断
void controlDelaySwitch2(modbus_t* ctx, uint16_t* write_data, int addr, int num_registers) {
    int rc;
    
    // 发送控制延时通断的命令
    rc = modbus_write_registers(ctx, addr, num_registers, write_data);
    if (rc == -1) {
        std::cerr << "发送Modbus命令失败: " << modbus_strerror(errno) << "\n";
        modbus_close(ctx);
        modbus_free(ctx);
        exit(1);
    }

    //std::cout << "成功发送控制延时通断的命令\n";
}

// 8. 命令触发自动轮换控制
// 命令触发自动轮换控制的Modbus命令
void triggerAutoRotationControl(modbus_t* ctx, uint16_t* write_data, int addr) {
    int rc;
    
    // 发送命令触发自动轮换控制的命令
    rc = modbus_write_registers(ctx, addr, 3, write_data);
    if (rc == -1) {
        std::cerr << "发送Modbus命令失败: " << modbus_strerror(errno) << "\n";
        modbus_close(ctx);
        modbus_free(ctx);
        exit(1);
    }

    //std::cout << "成功发送命令触发自动轮换控制的命令\n";
}


int main(int argc, char** argv) {
    // 初始化ROS节点
    ros::init(argc, argv, "io_device");
    ros::NodeHandle nh;
    modbus_t* ctx;
    int rc;
    uint8_t query[64]; // 存储发送的查询命令
    uint8_t read_buffer[MODBUS_MAX_READ_BITS]; // 读取的数据缓冲区
    uint16_t write_data[9]; // 写入的数据缓冲区
    char version[32]; // 存储版本信息的字符数组

    // 创建Modbus RTU的上下文
    ctx = modbus_new_rtu("/dev/ttyUSB1", 9600, 'N', 8, 1);
    if (ctx == NULL) {
        std::cerr << "无法创建Modbus上下文\n";
        return 1;
    }
    modbus_set_slave(ctx, 0x01);
    // 连接Modbus从设备

    // 尝试连接Modbus从设备，一直重试直到连接成功
    while (true) {
        if (modbus_connect(ctx) == -1) {
            //std::cerr << "连接失败: " << modbus_strerror(errno) << "\n";
            //std::cerr << "尝试重新连接...\n";
            std::this_thread::sleep_for(std::chrono::seconds(5));  // 等待1秒再尝试
        } else {
            std::cout << "成功连接到Modbus从设备\n";
            break;  // 连接成功，跳出循环
        }
    }


    // 每种功能的Modbus命令示例
// 1.调用功能函数打印开关状态
    //printSwitchStates(ctx);
// 2.读取输出端口状态
    //readOutputPortStatus(ctx);
    //getControllerVersion(ctx, version);
// 3.控制第1路输出通断
///////////////////////***********上电启动***********///////////////////////
/*
//发电机启动
    controlOutputPort(ctx, 1, true); // 控制第1路输出，true为通，false为关
    std::this_thread::sleep_for(std::chrono::seconds(1));//延时

//加热斧启动
    controlOutputPort(ctx, 2, true);
    std::this_thread::sleep_for(std::chrono::seconds(1));//延时
//原点初始化开关
    controlOutputPort(ctx, 3, true);    
    std::this_thread::sleep_for(std::chrono::seconds(1));//延时
*/
///////////////////////***********根据工作状态启动***********///////////////////////
 int zuoye_mode = 0;
 int shebei1=-1;//设备1
 int shebei2=-1;//设备2
 int shebei3=-1;//设备3
 int shebei4=-1;//设备4
 int shebei5=-1;//设备5
 int shebei6=-1;//设备6
 int lastShebei1 = -1; // 用于保存上一次获取的shebei1的值，初始化为-1表示未初始化
 int lastShebei2 = -1; // 用于保存上一次获取的shebei1的值，初始化为-1表示未初始化
 int lastShebei3 = -1; // 用于保存上一次获取的shebei1的值，初始化为-1表示未初始化
 int lastShebei4 = -1; // 用于保存上一次获取的shebei1的值，初始化为-1表示未初始化
 int lastShebei5 = -1; // 用于保存上一次获取的shebei1的值，初始化为-1表示未初始化
 int lastShebei6 = -1; // 用于保存上一次获取的shebei1的值，初始化为-1表示未初始化
 int currentShebei1 = -1; // 用于保存当前获取的shebei1的值，初始化为-1表示未获取到
 int currentShebei2 = -1; // 用于保存当前获取的shebei1的值，初始化为-1表示未获取到
 int currentShebei3 = -1; // 用于保存当前获取的shebei1的值，初始化为-1表示未获取到
 int currentShebei4 = -1; // 用于保存当前获取的shebei1的值，初始化为-1表示未获取到
 int currentShebei5 = -1; // 用于保存当前获取的shebei1的值，初始化为-1表示未获取到
 int currentShebei6 = -1; // 用于保存当前获取的shebei1的值，初始化为-1表示未获取到

    while (ros::ok()) 
    {
        if (ros::param::get("/shebei1", currentShebei1)) 
        {
        // 设备1--开槽机
        if (currentShebei1 != lastShebei1)
        { 
            lastShebei1 = currentShebei1; // 更新上一次的shebei1的值
            switch (currentShebei1) 
            {
                case 0:

                    controlOutputPort(ctx, 1, true); // 控制第1路输出，true表示打开
                    std::this_thread::sleep_for(std::chrono::seconds(2)); // 延时5秒
                    controlOutputPort(ctx, 1, false); // 控制第1路输出，false表示关闭
                    //std::this_thread::sleep_for(std::chrono::seconds(5)); // 延时5秒
                    break; // 跳出switch语句
                case 1:
                    controlOutputPort(ctx, 1, true); // 控制第1路输出，true表示打开
                    std::this_thread::sleep_for(std::chrono::seconds(2)); // 延时5秒
                    controlOutputPort(ctx, 1, false); // 控制第1路输出，false表示关闭
                    break; // 跳出switch语句
                default:
                    // 如果shebei1的值不是0或1，可以在此处添加处理逻辑
                    break; // 可选的，因为已经是switch的最后一个case，但添加break是个好习惯
            }
        }
        }
        if (ros::param::get("/shebei2", currentShebei2)) 
        {
        // 设备2--抱闸开关
        if (currentShebei2 != lastShebei2)
        { 
            lastShebei2 = currentShebei2; 
            switch (currentShebei2) 
            {
                case 0:
                    controlOutputPort(ctx, 2, false); // 控制第1路输出，false表示关闭
                    //std::this_thread::sleep_for(std::chrono::seconds(5)); // 延时5秒
                    break; // 跳出switch语句
                case 1:
                    controlOutputPort(ctx, 2, true); // 控制第1路输出，true表示打开
                    //std::this_thread::sleep_for(std::chrono::seconds(5)); // 延时5秒
                    break; // 跳出switch语句
                default:
                    // 如果shebei1的值不是0或1，可以在此处添加处理逻辑
                    break; // 可选的，因为已经是switch的最后一个case，但添加break是个好习惯
            }
        }
        }
        if (ros::param::get("/shebei3", currentShebei3)) 
        {
        // 
        if (currentShebei3 != lastShebei3)
        { 
            lastShebei3 = currentShebei3; // 更新上一次的shebei1的值
            switch (currentShebei3) 
            {
                case 0:
                    controlOutputPort(ctx, 3, false); // 控制第1路输出，false表示关闭
                    break; // 跳出switch语句
                case 1:
                    controlOutputPort(ctx, 3, true); // 控制第1路输出，true表示打开
                    break; // 跳出switch语句
                default:
                    // 如果shebei1的值不是0或1，可以在此处添加处理逻辑
                    break; // 可选的，因为已经是switch的最后一个case，但添加break是个好习惯
            }
        }
        }
        if (ros::param::get("/shebei4", currentShebei4)) 
        {
        // 设备1--抱闸开关
        if (currentShebei4 != lastShebei4)
        { 
            lastShebei4 = currentShebei4; // 更新上一次的shebei1的值
            switch (currentShebei4) 
            {
                case 0:
                    controlOutputPort(ctx, 4, false); // 控制第1路输出，false表示关闭
                    //std::this_thread::sleep_for(std::chrono::seconds(5)); // 延时5秒
                    break; // 跳出switch语句
                case 1:
                    controlOutputPort(ctx, 4, true); // 控制第1路输出，true表示打开
                    //std::this_thread::sleep_for(std::chrono::seconds(5)); // 延时5秒
                    break; // 跳出switch语句
                default:
                    // 如果shebei1的值不是0或1，可以在此处添加处理逻辑
                    break; // 可选的，因为已经是switch的最后一个case，但添加break是个好习惯
            }
        }
        }
        if (ros::param::get("/shebei5", currentShebei5)) 
        {
        // 设备1--抱闸开关
        if (currentShebei5 != lastShebei5)
        { 
            lastShebei5 = currentShebei5; // 更新上一次的shebei1的值
            switch (currentShebei5) 
            {
                case 0:
                    controlOutputPort(ctx, 5, false); // 控制第1路输出，false表示关闭
                    //std::this_thread::sleep_for(std::chrono::seconds(5)); // 延时5秒
                    break; // 跳出switch语句
                case 1:
                    controlOutputPort(ctx, 5, true); // 控制第1路输出，true表示打开
                    //std::this_thread::sleep_for(std::chrono::seconds(5)); // 延时5秒
                    break; // 跳出switch语句
                default:
                    // 如果shebei1的值不是0或1，可以在此处添加处理逻辑
                    break; // 可选的，因为已经是switch的最后一个case，但添加break是个好习惯
            }
        }
        }
        if (ros::param::get("/shebei6", currentShebei6)) 
        {
        // 设备1--抱闸开关
        if (currentShebei6 != lastShebei6)
        { 
            lastShebei6 = currentShebei6; // 更新上一次的shebei1的值
            switch (currentShebei6) 
            {
                case 0:
                    controlOutputPort(ctx, 6, false); // 控制第1路输出，false表示关闭
                    //std::this_thread::sleep_for(std::chrono::seconds(5)); // 延时5秒
                    break; // 跳出switch语句
                case 1:
                    controlOutputPort(ctx, 6, true); // 控制第1路输出，true表示打开
                    //std::this_thread::sleep_for(std::chrono::seconds(5)); // 延时5秒
                    break; // 跳出switch语句
                default:
                    // 如果shebei1的值不是0或1，可以在此处添加处理逻辑
                    break; // 可选的，因为已经是switch的最后一个case，但添加break是个好习惯
            }
        }
        }         
        // 检查参数值
    /*
        if (ros::param::get("/zuoye_mode", zuoye_mode)) 
        {
            switch (zuoye_mode) 
            {
                case 1:
                    // 开槽机启动
                    //std::this_thread::sleep_for(std::chrono::seconds(5));//延时
                    controlOutputPort(ctx, 6, true);
                    std::this_thread::sleep_for(std::chrono::seconds(1));//延时
                    // 吸尘器，喷砂机启动
                    controlOutputPort(ctx, 7, true);
                    std::this_thread::sleep_for(std::chrono::seconds(1));//延时
                    // 沥青泵启动
                    controlOutputPort(ctx, 8, true);
                    std::this_thread::sleep_for(std::chrono::seconds(1));
                    break;
                case 2:
                    controlOutputPort(ctx, 6, false);
                    std::this_thread::sleep_for(std::chrono::seconds(1));//延时
                    // 吸尘器，喷砂机启动
                    controlOutputPort(ctx, 7, true);
                    // 沥青泵启动
                    std::this_thread::sleep_for(std::chrono::seconds(1));//延时
                    controlOutputPort(ctx, 8, true);
                    std::this_thread::sleep_for(std::chrono::seconds(1));
                    break;
                default:
                    // 如果zuoye_mode的值不为1也不为2
                    controlOutputPort(ctx, 6, false);
                    std::this_thread::sleep_for(std::chrono::seconds(1));//延时
                    controlOutputPort(ctx, 7, false);
                    std::this_thread::sleep_for(std::chrono::seconds(1));//延时
                    controlOutputPort(ctx, 8, false);
                    std::this_thread::sleep_for(std::chrono::seconds(1));//延时
                    break;
            }
        } 
        else 
        {
            // 参数未找到或读取错误
            std::cerr << "读取/zuoye_mode参数错误\n";
        }
        */
    }

    return 0;
}
