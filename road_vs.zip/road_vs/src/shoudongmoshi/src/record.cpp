#include "ros/ros.h"
#include <iostream>
#include <fstream>
#include <ctime>
#include <iomanip>
#include <nav_msgs/Odometry.h>
#include "std_msgs/String.h"
#include <rosgraph_msgs/Log.h>
#include <iomanip> // 用于设置输出精度
#include <boost/filesystem.hpp>
namespace fs = boost::filesystem;
double car_x = 0.0;
double car_y = 0.0;
double global_cam_x0 = 0.0;
double global_cam_y0 = 0.0;
double global_cam_theta0 = 0.0;
double global_cam_edge0 = 0;
double current_mode;
void fixCallback(const nav_msgs::Odometry::ConstPtr &msg);
void clearCsvFiles(const std::string& directory) {
    ROS_INFO_STREAM("Clearing CSV files in " << directory);
    fs::path dir(directory);
    fs::directory_iterator end_itr;

    for (fs::directory_iterator itr(dir); itr != end_itr; ++itr) {
        if (fs::is_regular_file(itr->status()) && itr->path().extension() == ".csv") {
            fs::remove(itr->path());
            ROS_INFO_STREAM("Removed file: " << itr->path());
        }
    }

    ROS_INFO("CSV files cleared");
}
class NodeRecorder
{
    public:
    NodeRecorder(){
        startTime = getCurrentTime();
        ROS_INFO("Node opened at: %s", startTime.c_str());
        std::string csvFileName = "/home/passoni/ros_record/" + startTime + ".csv";
        csvFile.open(csvFileName);
        csvFile << "开机时间," << startTime << std::endl;
    }
    void recordEvent(const std::string &event){
        std::string eventTime = getCurrentTime();
        csvFile << event << "," << eventTime << std::endl;csvFile.flush();
    }
    void fixCallbackWrapper(const rosgraph_msgs::Log::ConstPtr& msg){
        ros::NodeHandle nh;NodeRecorder recorder;
    }
    void waitForShutdown(){
        ros::NodeHandle nh; // 定义 ROS 节点句柄变量
        ros::Subscriber shutdown_sub = nh.subscribe("/rosout", 1, &NodeRecorder::fixCallbackWrapper, this);
        std::string endTime = getCurrentTime();
        ROS_INFO("Node closed at: %s", endTime.c_str());
        csvFile << "关机时间," << endTime << std::endl;
        csvFile.close();
        
    }
    private:
        std::ofstream csvFile;std::string startTime;
        std::string getCurrentTime(){time_t now = time(0);struct tm tstruct;char buf[80];tstruct = *localtime(&now);strftime(buf, sizeof(buf), "%m.%d.%H:%M", &tstruct);return buf;
        }
};

int main(int argc, char **argv)
{
    ros::init(argc, argv, "record");
    ros::NodeHandle nh;
    std::string csvDirectory = "/home/passoni/ros_record/";
    clearCsvFiles(csvDirectory);
    // 创建一个订阅者来监听机器人的里程消息
    //ros::Subscriber fix_sub = nh.subscribe<nav_msgs::Odometry>("YOUR_ODOM_TOPIC", 10, fixCallback);

    // 创建一个 NodeRecorder 对象来记录事件
    NodeRecorder recorder;
    int previous_mode = -1;
    int previous_now_is_record = -1;
    int previous_liefeng_length = -1;
    int previous_liefeng_width = -1;
    double current_mode;
    int now_is_record = -1;
    double liefeng_length;
    double liefeng_width;
    int shifoukaicao;
    while (ros::ok()) {
        nh.getParam("/current_mode", current_mode);
        nh.getParam("/now_is_record", now_is_record);
        if (now_is_record == 1) {
        // 如果 now_is_record 为 1，执行记录功能
        recorder.recordEvent("记录时间");
        ROS_INFO("5555 %s", "记录时间");
        ros::param::set("/now_is_record", 0);
        }
        if ((current_mode != previous_mode)){
            if(current_mode==0)
            {
                recorder.recordEvent("手动开始时间");
                //fixCallback(nav_msgs::Odometry::ConstPtr());
                //recorder.recordEvent("记录当前位置: car_x = " + std::to_string(car_x) + ", car_y = " + std::to_string(car_y));
                break;
            }
            if(current_mode==1)
            {
                recorder.recordEvent("自动开始时间");
                //fixCallback(nav_msgs::Odometry::ConstPtr());
                //recorder.recordEvent("记录当前位置: car_x = " + std::to_string(car_x) + ", car_y = " + std::to_string(car_y));
                break;
            }
            if(current_mode==2)
            {
                recorder.recordEvent("扫描开始时间");
                //fixCallback(nav_msgs::Odometry::ConstPtr());
                //recorder.recordEvent("记录当前位置: car_x = " + std::to_string(car_x) + ", car_y = " + std::to_string(car_y));                
                break;
            }
            if(current_mode==3)
            {
                // 记录作业模式开始时间
                recorder.recordEvent("作业开始时间");
                ROS_INFO("3333 %s", "作业开始时间");
                // 获取裂缝长度和裂缝宽度
                nh.getParam("liefeng_length", liefeng_length);
                nh.getParam("liefeng_width", liefeng_width);
                nh.getParam("shifoukaicao", shifoukaicao);
                // 判断是否开槽，并记录相应信息
                std::string kaicaoInfo;
                if (shifoukaicao == 1) {
                    kaicaoInfo = "开槽";
                } else {
                    kaicaoInfo = "不开槽";
                }
                // 将裂缝长度和宽度格式化为两位小数
                std::stringstream lengthStream, widthStream;
                lengthStream << std::fixed << std::setprecision(2) << liefeng_length;
                widthStream << std::fixed << std::setprecision(2) << liefeng_width;
                std::string lengthStr = lengthStream.str();
                std::string widthStr = widthStream.str();
                // 记录裂缝长度和宽度
                recorder.recordEvent("裂缝长度: " + lengthStr);
                recorder.recordEvent("裂缝宽度: " + widthStr);
                recorder.recordEvent(kaicaoInfo);
                // 将裂缝信息和开槽信息合并为一个字符串
                //std::string crackInfo = "裂缝长度: " + std::to_string(liefeng_length) + ", 裂缝宽度: " + std::to_string(liefeng_width) + ",  " + kaicaoInfo;
                // 记录到文件，裂缝信息作为第二行
                //recorder.recordEvent(crackInfo);
                break;
            }
        /*
        case 5:recorder.recordEvent("记录保存结束时间");
        ROS_INFO("5555 %s", "记录保存结束时间");
        recorder.waitForShutdown();
        break;  
        */      
        }
        previous_mode = current_mode;
        }
    ros::spin();

    // 节点关闭时，等待节点关闭
    recorder.waitForShutdown();

    return 0;
}

