#include <ros/ros.h>
#include <std_msgs/String.h>
#include <geometry_msgs/Twist.h>
#include <string>
#include <serial/serial.h>
#include <iostream>
#include <jsoncpp/json/json.h>
#include "geometry_msgs/Point.h" 
#include "ssr_pkg/custommessage.h"
#include <thread>
#include <fstream>
#include <filesystem>
#include <iomanip>
namespace fs = std::filesystem; // 引入文件系统命名空间
//#include "operating_ctrl/custommessage.h"
//定义Position变量
struct Position {
    int x0;
    int y0;
};
using namespace std;
ros::Publisher cmd_vel_pub;
// 全局变量
double current_mode;
int temperature_work=1;
double temperature;
double now_is_kaicao_bufeng;
int bufeng_step;
int kaicao_step;
int shutdown;
int fangxianghuizheng;
std::string port = "/dev/ttyUSB7";
uint32_t baudrate = 9600;
serial::Serial ser;
bool isRecording = false;
std::vector<Position> positionBuffer;
bool error_published = false;  // 添加一个标志，用于跟踪是否已经发布过错误消息
// 声明为全局变量
int k = 1;
// 声明 positionLoop() 函数，告诉编译器该函数将在后面定义
void positionLoop();
void sendCSVBeforeShutdown();
void serialCallback(const std_msgs::String::ConstPtr& msg)
{
    ros::NodeHandle nh;
    // 从字符串中解析x和y坐标
std::string data_str = msg->data;
size_t start_pos = 0;
size_t end_pos = 0;
if (data_str.find("dianziweilan:") == 0) {
    std::vector<std::string> data_vec;
    // 查找起始位置
    std::string start_str = "dianziweilan:";
    size_t start_pos = start_str.length();
    // 提取数据部分
    std::string data_part = data_str.substr(start_pos);
    
    // 分割数据并存储到向量中
    size_t pos = 0;
    while ((pos = data_part.find(";")) != std::string::npos) {
        std::string token = data_part.substr(0, pos);
        data_vec.push_back(token);
        data_part.erase(0, pos + 1);
    }
    // 添加最后一个数据
    data_vec.push_back(data_part);
    
// 检查是否成功提取四个数据
if (data_vec.size() == 4) {
    std::string shuju1_str = data_vec[0];
    std::string shuju2_str = data_vec[1];
    std::string shuju3_str = data_vec[2];
    std::string shuju4_str = data_vec[3];

    double shuju1 = std::stod(shuju1_str);
    double shuju2 = std::stod(shuju2_str);
    double shuju3 = std::stod(shuju3_str);
    double shuju4 = std::stod(shuju4_str);

    ros::param::set("/dianziweilan_up", shuju1);
    ros::param::set("/dianziweilan_down", shuju2);
    ros::param::set("/dianziweilan_left", shuju3);
    ros::param::set("/dianziweilan_right", shuju4);

    // 输出结果
    std::cout << "shuju1: " << shuju1 << std::endl;
    std::cout << "shuju2: " << shuju2 << std::endl;
    std::cout << "shuju3: " << shuju3 << std::endl;
    std::cout << "shuju4: " << shuju4 << std::endl;
} else {
    std::cout << "无法提取四个数据。" << std::endl;
}

}
 
while ((start_pos = data_str.find("x:", start_pos)) != std::string::npos) {
    start_pos += 2; // 跳过"x:"
    end_pos = data_str.find(";", start_pos); // 寻找下一个分号位置

    if (end_pos != std::string::npos) {
        // 在分号位置之前找到逗号位置
        size_t comma_pos = data_str.find(",", start_pos);
        
        if (comma_pos != std::string::npos && comma_pos < end_pos) {
            std::string x_str = data_str.substr(start_pos, comma_pos - start_pos);
            std::string y_str = data_str.substr(comma_pos + 4, end_pos - comma_pos - 4); // 跳过逗号和" y:"部分
            try {
                double x = std::stod(x_str);
                double y = std::stod(y_str);
                
                // 根据摇杆数据计算线速度和角速度
                geometry_msgs::Twist cmd_vel_msg;
                cmd_vel_msg.linear.x = k * x; 
                cmd_vel_msg.angular.z = -1 * y * M_PI / 20; 
                if (nh.getParam("/current_mode", current_mode)) {
                    if (current_mode == 0) {
                        cmd_vel_pub.publish(cmd_vel_msg); // 发布速度指令
                        break; // 处理完第一个坐标对后退出循环
                    }
                }

            }
            catch(const std::exception& e) {
                ROS_ERROR("Failed to parse joystick data: %s", e.what());
            }
        }
        else {
            ROS_ERROR("Invalid joystick data format: %s", data_str.substr(start_pos, end_pos - start_pos).c_str());
        }

        start_pos = end_pos + 1; // 更新起始位置以继续寻找下一个坐标对
    }
}

static bool mode_1_received = false; // 标志是否接收到"2222"消息
    if (msg->data == "1111")
{
    ros::param::set("/current_mode", 0);
    mode_1_received = true;
}   
    else if (msg->data == "2222")
    {
    ros::param::set("/current_mode", 1);
    mode_1_received = false;
    }
    else if (msg->data == "3333")
    {
    ros::param::set("/current_mode", 4);
    mode_1_received = false;
    }
    else if (msg->data == "4444")
    {
    ros::param::set("/only_kaicao_or_bufeng", 1);
    ros::param::set("/current_mode", 1);
    mode_1_received = false;
    }
    else if (msg->data == "8888")
    {
    ros::param::set("/now_is_record", 1);
    sendCSVBeforeShutdown();
    }
    else if (msg->data == "nishizhen")
    {
    geometry_msgs::Twist cmd_vel_msg;
    cmd_vel_msg.linear.x = 0.002; 
    cmd_vel_msg.angular.z = 1; 
    cmd_vel_pub.publish(cmd_vel_msg);
    ros::Duration(3.0).sleep();    
    cmd_vel_msg.linear.x = 0.001; 
    cmd_vel_msg.angular.z = 1; 
    cmd_vel_pub.publish(cmd_vel_msg);
    }else if (msg->data == "shunshizhen")
    {
    geometry_msgs::Twist cmd_vel_msg;
    cmd_vel_msg.linear.x = 0.002; 
    cmd_vel_msg.angular.z = -1; 
    cmd_vel_pub.publish(cmd_vel_msg);
    ros::Duration(3.0).sleep();    
    cmd_vel_msg.linear.x = 0.001; 
    cmd_vel_msg.angular.z = -1; 
    cmd_vel_pub.publish(cmd_vel_msg);
    }else if (msg->data == "tingzhi")
    {
    geometry_msgs::Twist cmd_vel_msg;
    cmd_vel_msg.linear.x = 0.0; 
    cmd_vel_msg.angular.z = 0.0; 
    cmd_vel_pub.publish(cmd_vel_msg);
    } 
    else if (msg->data == "6666")
    {
    ros::param::set("/fangxianghuizheng",1);
    }     
    if (mode_1_received)
{
    // 根据接收到的串口数据加速，减速操作
    if (msg->data == "7777")
    {
        k += 1; // 如果接收到 "7777" 数据，k+1
    }
        else if (msg->data == "9999")
    {
        k -= 1; // 如果接收到 "9999" 数据，k-1
    }
        else if (msg->data == "1000")
    {
        ros::param::set("/shebei1", 0);
    }
        else if (msg->data == "2000")
    {
        ros::param::set("/shebei2", 0);
    }
        else if (msg->data == "3000")
    {
        ros::param::set("/shebei3", 0);
    }
        else if (msg->data == "4000")
    {
        ros::param::set("/shebei4", 0);
    }
        else if (msg->data == "5000")
    {
        ros::param::set("/shebei5", 0);
    }
        else if (msg->data == "6000")
    {
        ros::param::set("/shebei6", 0);
    }    
        else if (msg->data == "1001")
    {
        ros::param::set("/shebei1", 1);
    }
        else if (msg->data == "2001")
    {
        ros::param::set("/shebei2", 1);
    }
        else if (msg->data == "3001")
    {
        ros::param::set("/shebei3", 1);
    }
        else if (msg->data == "4001")
    {
        ros::param::set("/shebei4", 1);
    }
        else if (msg->data == "5001")
    {
        ros::param::set("/shebei5", 1);
    }
        else if (msg->data == "6001")
    {
        ros::param::set("/shebei6", 1);
    }
}
}
// 回调函数，处理收到的 crack_data 数据和参数数据
void localPositionCallback(const ssr_pkg::custommessage::ConstPtr& msg)
{
    if (!ser.isOpen()) {
        //ROS_INFO_STREAM("Serial port is not open. Reopening...");
        try {
            ser.setPort(port);
            ser.setBaudrate(baudrate);
            serial::Timeout timeout = serial::Timeout::simpleTimeout(1000);
            ser.setTimeout(timeout);
            ser.open();
            if (ser.isOpen()) {
                //ROS_INFO_STREAM("Serial port reopened successfully.");
            } else {
                //ROS_ERROR_STREAM("Failed to reopen serial port.");
                return;
            }
        } catch (serial::IOException& e) {
            //ROS_ERROR_STREAM("Unable to open serial port. Exception: " << e.what());
            return;
        }
    }

    if (msg->ZA == "ZA") 
    {
        isRecording = true;
        positionBuffer.clear();  
    } 

    if (isRecording) 
    {
        Position pos; 
        for (size_t i = 0; i < msg->coords.size(); i += 10) 
        {
            int x = msg->coords[i];
            int y = msg->coords[i + 1]; 
            positionBuffer.push_back({x, y});
        }
        if (msg->ZE == "ZE") 
        {
            isRecording = false;
        }
    }

    ros::param::get("/now_is_kaicao_bufeng", now_is_kaicao_bufeng);
    ros::param::get("/bufeng_step", bufeng_step);
    ros::param::get("/kaicao_step", kaicao_step);
    // 发送 crack_data
    unsigned int count = 0; // 计数器
    for (unsigned int i = 0; i < positionBuffer.size() && count < 30; ++i) {
        std::string data_str;

        data_str += "crack:" + std::to_string(positionBuffer[i].x0) + "," + std::to_string(positionBuffer[i].y0) + ";";

        if (ser.isOpen()) {
            ser.write(data_str);
            //ROS_INFO_STREAM("Sent crack data: " << data_str);
            count++; // 每发送一次数据，计数器加1
        } else {
            ROS_ERROR_STREAM("串口未打开，无法写入数据。");
        }
        ros::Duration(0.3).sleep();
    }
    // 发送 status_data
    std::string status_data_str = "status:" + std::to_string((now_is_kaicao_bufeng == 0) ? 0 : 1) + ";";
    if (ser.isOpen()) {
        ser.write(status_data_str);
        //ROS_INFO_STREAM("Sent status data: " << status_data_str);
    } else {
        ROS_ERROR_STREAM("串口未打开，无法写入数据。");
    }
    //ros::Duration(1.0).sleep();
    positionLoop();
}
void sendCSVBeforeShutdown() {
    // 获取文件夹路径
    std::string folder_path = "/home/passoni/ros_record"; // 实际的文件夹路径
    // 遍历文件夹下的所有CSV文件
    for (const auto& entry : fs::directory_iterator(folder_path)) {
        if (entry.path().extension() == ".csv") {
            // 读取CSV文件内容
            std::ifstream file(entry.path());
            std::string line;
            while (std::getline(file, line)) {
                try {
                    // 发送CSV数据
                    ser.write(line);
                    //ros::Duration(1).sleep(); // 等待1秒
                } catch (serial::IOException& e) {
                    ROS_ERROR_STREAM("Error writing to serial port: " << e.what());
                    return;
                }
            }
        }
    }
    ros::param::set("/now_is_record", 0);
}
//发送 position_data
void positionLoop()
{
    ros::NodeHandle nh;  
    ros::param::get("/now_is_kaicao_bufeng", now_is_kaicao_bufeng);
    //ros::param::get("/bufeng_step", bufeng_step);
    ros::param::get("/kaicao_step", kaicao_step);
    ros::param::get("/bufeng_step", bufeng_step);
    ros::param::get("/current_mode", current_mode);  
    ros::Rate loop_rate(1.0/1);
        // 发送 status_data
    std::string status_data_str = "status:" + std::to_string((now_is_kaicao_bufeng == 0) ? 0 : 1) + ";";
    if (ser.isOpen()) {
        ser.write(status_data_str);
        //ROS_INFO_STREAM("Sent status data: " << status_data_str);
    } else {
        ROS_ERROR_STREAM("串口未打开，无法写入数据。");
    }
    while (ros::ok() && kaicao_step < 11)
    {
        // 获取参数值
        ros::param::get("/now_is_kaicao_bufeng", now_is_kaicao_bufeng);
        // 发送 position_data
        std::string pos_data_str = "pos:" + std::to_string((now_is_kaicao_bufeng == 0) ? kaicao_step : bufeng_step) + ";";
        if (ser.isOpen())
        {
            ser.write(pos_data_str);
            //ROS_INFO_STREAM("Sent position data: " << pos_data_str);
        }
        else
        {
            ROS_ERROR_STREAM("串口未打开，无法写入数据。");
        }

        // 设置参数值加1
        kaicao_step++;
        //bufeng_step++;       
        ros::param::set("/kaicao_step", kaicao_step);
        ros::param::get("/kaicao_step", kaicao_step);  
        loop_rate.sleep();      
        // 延时1秒
    }
    ros::param::get("/now_is_kaicao_bufeng", now_is_kaicao_bufeng);
    // 发送 status_data
    status_data_str = "status:" + std::to_string((now_is_kaicao_bufeng == 0) ? 1 : 0) + ";";
    if (ser.isOpen()) {
        ser.write(status_data_str);
        //ROS_INFO_STREAM("Sent status data: " << status_data_str);
    } else {
        //ROS_ERROR_STREAM("串口未打开，无法写入数据。");
    }
    while (ros::ok() && bufeng_step < 11)
    {
        // 获取参数值
        ros::param::get("/now_is_kaicao_bufeng", now_is_kaicao_bufeng);
        // 发送 position_data
        std::string pos_data_str = "pos:" + std::to_string((now_is_kaicao_bufeng == 1) ? kaicao_step : bufeng_step) + ";";
        if (ser.isOpen())
        {
            ser.write(pos_data_str);
            //ROS_INFO_STREAM("Sent position data: " << pos_data_str);
        }

        // 设置参数值加1
        //kaicao_step++;
        bufeng_step++;       
        ros::param::set("/bufeng_step", bufeng_step);
        ros::param::get("/bufeng_step", bufeng_step);        
        // 延时1秒
        loop_rate.sleep();
    }
}
void zhongliangLoop()
{
    ros::NodeHandle nh;
    double zhongliang;
    nh.getParam("/zhongliang", zhongliang);
    ros::Rate loop_rate(1.0/60); // 设置循环频率为每60秒执行一次
    while (ros::ok())
    {
        // 获取参数值
        ros::param::get("/zhongliang", zhongliang);
        // 发送 zhongliang
        std::stringstream ss;
        ss << std::fixed << std::setprecision(2) << zhongliang; // 设置保留两位小数
        std::string zhongliang_data_str = "zhongliang:" + ss.str() + ";";
        if (ser.isOpen())
        {
            ser.write(zhongliang_data_str);
            //ROS_INFO_STREAM("Sent zhongliang data: " << zhongliang_data_str);
        }
        ros::spinOnce();   
        loop_rate.sleep(); // 控制循环频率        
        //}
    }
}
void rangeLoop()
{
    ros::NodeHandle nh;
    int chaochufanwei = 0;
    int wuliefeng = 0;
    int zhaodaoliefeng = 0;
    nh.getParam("/chaochufanwei", chaochufanwei);
    nh.getParam("/wuliefeng",wuliefeng);
    nh.getParam("/zhaodaoliefeng",zhaodaoliefeng);
    while (ros::ok() && chaochufanwei <2)
    {
        nh.getParam("/chaochufanwei", chaochufanwei);
        nh.getParam("/wuliefeng",wuliefeng);
        nh.getParam("/zhaodaoliefeng",zhaodaoliefeng);
        if (chaochufanwei == 1)
        {
            std::string chaochufanwei_data_str = "chaochufanwei:1;";
            if (ser.isOpen())
            {
                ser.write(chaochufanwei_data_str);
                //ROS_INFO_STREAM("Sent chaochufanwei data: " << chaochufanwei_data_str);
            }
            nh.setParam("/chaochufanwei",0);
        }
        if (wuliefeng == 1)
        {
            std::string wuliefeng_data_str = "wuliefeng:1;";
            if (ser.isOpen())
            {
                ser.write(wuliefeng_data_str);
                //ROS_INFO_STREAM("Sent wuliefeng data: " << wuliefeng_data_str);
            }
            nh.setParam("/wuliefeng",0);
        }
        if (zhaodaoliefeng == 1)
        {
            std::string zhaodaoliefeng_data_str = "zhaodaoliefeng:1;";
            if (ser.isOpen())
            {
                ser.write(zhaodaoliefeng_data_str);
                //ROS_INFO_STREAM("Sent zhaodaoliefeng data: " << zhaodaoliefeng_data_str);
            }
            nh.setParam("/zhaodaoliefeng",0);
        }
        ros::spinOnce();           
    }
}
void serialCommunicationLoop()
{
    ros::NodeHandle nh;
    ros::Rate rate(100);
    while (ros::ok())
    {
        try
        {
            ser.setPort(port);
            ser.setBaudrate(baudrate);
            serial::Timeout timeout = serial::Timeout::simpleTimeout(1000);
            ser.setTimeout(timeout);
            ser.open();
            if (ser.isOpen())
            {
                ROS_INFO("Successfully opened serial port %s", port.c_str());
                error_published = false;  // 重置错误发布标志
                while (ros::ok())
                {
                    if (ser.available())
                    {
                        std_msgs::String msg;
                        msg.data = ser.read(ser.available());
                        ROS_INFO("receive data: %s", msg.data.c_str());
                        ros::Publisher pub = nh.advertise<std_msgs::String>("serial_data", 10);
                        pub.publish(msg);
                    }
                    ros::spinOnce();
                    rate.sleep();
                }
            }
        }
        catch (serial::IOException& e)
        {
            if (!error_published)
            {
                cout << "无法打开串口 " << port << " 的 modbus 设备。" << endl;
                error_published = true;  // 设置错误发布标志
            }
        }
        // 关闭串口
        ser.close();
    }
}
int main(int argc, char** argv)
{
    ros::init(argc, argv, "shoudongmoshi");
    ros::NodeHandle nh;
    ros::Publisher pub = nh.advertise<std_msgs::String>("serial_data", 10);
    ros::Subscriber sub_crack = nh.subscribe("crack_position", 100000, localPositionCallback);
    ros::Subscriber sub_serial = nh.subscribe("serial_data", 10, serialCallback);
    cmd_vel_pub = nh.advertise<geometry_msgs::Twist>("cmd_vel", 10);
    std::thread serial_thread(serialCommunicationLoop);
    std::thread zhongliang_thread(zhongliangLoop);
    std::thread range_thread(rangeLoop);
    //std::thread pos_thread(positionLoop);
    // 使用析构函数来执行关闭前的操作
    //std::shared_ptr<std::thread> cleanup_thread = std::make_shared<std::thread>(sendCSVBeforeShutdown);
    ros::spin();  // 主线程继续进行 ROS 相关操作
    serial_thread.join();  // 等待串口通讯循环线程结束
    range_thread.join();
    //pos_thread.join();
    return 0;
}