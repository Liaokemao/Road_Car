#include<ros/ros.h>
#include<geometry_msgs/Twist.h>
#include <sensor_msgs/Joy.h>
#include<iostream>
#include <std_msgs/Float64.h>
int k = 1;
using namespace std;
double current_mode;
class wheeltec_joy
{
public:
    wheeltec_joy();
    std_msgs::Float64 vlinear_x; //默认值
    std_msgs::Float64 vlinear_z;
private:
    void callback(const sensor_msgs::Joy::ConstPtr& Joy); 
    //实例化节点
    ros::NodeHandle n; 
    ros::Subscriber sub ;
    ros::Publisher pub ;
    ros::Publisher cmd_vel_pub;
    //机器人的初始速度
    double vlinear,vangular;
    //手柄键值
    int axis_ang,axis_lin,scale_linear,scale_angular; 
    int dir,flag_mec;

};

wheeltec_joy::wheeltec_joy() 
{
   //读取参数服务器中的变量值
     flag_mec=0;

   ros::NodeHandle private_nh("~"); //创建节点句柄
   private_nh.param<int>("axis_linear",axis_lin,1); //默认axes[1]接收速度
   private_nh.param<int>("axis_angular",axis_ang,0);//默认axes[0]接收角度

   private_nh.param<int>("scale_linear",scale_linear,2); //默认axes[1]接收速度
   private_nh.param<int>("scale_angular",scale_angular,3);//默认axes[0]接收角度

   private_nh.param<double>("vlinear",vlinear,2);//默认线速度0.3 m/s
   private_nh.param<double>("vangular",vangular,0.25);//默认角速度1 单位rad/s

   pub = n.advertise<geometry_msgs::Twist>("cmd_vel",1000);//将速度发给机器人底盘节点
   sub = n.subscribe<sensor_msgs::Joy>("joy",1000,&wheeltec_joy::callback,this); //订阅手柄发来的数据
   cmd_vel_pub = n.advertise<geometry_msgs::Twist>("cmd_vel", 10);
   
} 

void wheeltec_joy::callback(const sensor_msgs::Joy::ConstPtr& Joy) //键值回调函数
 {
   double vangle_key,linera_key;
   double acce_x,acce_z;
   geometry_msgs::Twist v;
   vangle_key =Joy->axes[axis_ang];  //获取axes[0]的值
   linera_key =Joy->axes[axis_lin];  //获取axes[1]的值

   acce_x=Joy->axes[scale_linear]+ 1.0;   //读取右摇杆的值对机器人的线速度进行加减速处理
   acce_z=Joy->axes[scale_angular]+1.0;   //读取右摇杆的值对机器人的角速度进行加减速处理
   //判断前进后退
   if(linera_key>0) 
   {
       dir=1;
       vlinear_x.data=vlinear;
   } 
   else if(linera_key<0)
   {
      dir=-1;
      vlinear_x.data=-vlinear;
   }
   else  
   {
    dir=1;
    vlinear_x.data=0;
   }
   //判断左转右转，大于0为左转，小于0为右转
   if(vangle_key>0)       vlinear_z.data=vangular;
   else if(vangle_key<0)  vlinear_z.data=-vangular; 
   else vlinear_z.data=0;
   //处理数据
   if(Joy->buttons[0]==1) //按下A键时，恢复正常转向模式
     flag_mec=0;
     //ROS_INFO("Buttons0 IS DOWN");
   if(flag_mec) 
   {
   }
   else
   {
   v.linear.x = k * vlinear_x.data*acce_x;
   v.angular.z = dir*vlinear_z.data*acce_z;
   }
  if(Joy->buttons[1]==1) //按下B顺时针
 {
  ROS_INFO("Shunshizhen IS DOWN");
  n.setParam("/current_mode", 6);
  ros::Duration(1.0).sleep();
  geometry_msgs::Twist cmd_vel_msg;
  cmd_vel_msg.linear.x = 0.002; 
  cmd_vel_msg.angular.z = -1; 
  cmd_vel_pub.publish(cmd_vel_msg);
  ros::Duration(3.0).sleep();    
  cmd_vel_msg.linear.x = 0.001; 
  cmd_vel_msg.angular.z = 1; 
  cmd_vel_pub.publish(cmd_vel_msg);

 }
  if(Joy->buttons[2]==1) //按下A停止
 {
  ROS_INFO("Tingzhi IS DOWN");
  geometry_msgs::Twist cmd_vel_msg;
  cmd_vel_msg.linear.x = 0.0; 
  cmd_vel_msg.angular.z = 0.0; 
  cmd_vel_pub.publish(cmd_vel_msg);
  ros::Duration(1.0).sleep();
  n.setParam("/current_mode", 5);
 }
 if(Joy->buttons[3]==1) //按下X逆时针
 {
  n.setParam("/current_mode", 6);
  ros::Duration(1.0).sleep();
  ROS_INFO("Nishizhen IS DOWN");
  geometry_msgs::Twist cmd_vel_msg;
  cmd_vel_msg.linear.x = 0.002; 
  cmd_vel_msg.angular.z = 1; 
  cmd_vel_pub.publish(cmd_vel_msg);
  ros::Duration(3.0).sleep();    
  cmd_vel_msg.linear.x = 0.001; 
  cmd_vel_msg.angular.z = -1; 
  cmd_vel_pub.publish(cmd_vel_msg);
 }
  if(Joy->buttons[4]==1) //减速
 {
    if (k > 1) {
      k = k - 1;
      ROS_INFO("BUTTON4 IS DOWN");
    }
 }
   if(Joy->buttons[5]==1) //加速
 {
    if (k < 8) {
    k = k + 1;
    ROS_INFO("BUTTON5 IS DOWN");
    }
 }
   //打印输出
   //ROS_INFO("linear:%.3lf angular:%.3lf",vlinear_x.data,v.angular.z);
   n.getParam("/current_mode", current_mode);
   if (current_mode == 5)
   {
    pub.publish(v);
   }
 
}
int main(int argc,char** argv)
{
  ros::init(argc, argv, "joy_control");
  wheeltec_joy teleop_turtle;
  ros::NodeHandle n;
  
  ros::spin();
  return 0;

} 
