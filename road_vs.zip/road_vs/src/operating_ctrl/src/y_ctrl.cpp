/*
***************程序说明***************
本程序作业模式，根据局部相机提供的裂缝消息，转化为Y轴，开槽，补缝的控制指令
程序实现步骤: 1.void yPubCallback（）实现计算和发布电机真实控制量
            2.int main（）ros主函数
*/
#include "ros/ros.h"
#include "operating_ctrl/operating.h" 
#include "operating_ctrl/y.h"     
#include <std_msgs/Float32.h>
#include <string>
double y_s = 10;   // y轴电机导程，给定的常数值，单位mm
double A = 1000; //y轴电机分辨率
double T=1;//运动时间间隔
//double y_operating_ganshe0=30;//y轴干涉操作，位置
//double y_operating_ganshe1=-30;//y轴干涉
// 在循环外部定义变量保存小数部分的累加值
double y_motor_angle_accumulate = 0.0;
double y_ctrl_pub_rate=1;
double y_sum = 0;
int y_zhou_move = 0;
int now_is_kaicao_bufeng = -1;
double first_y = 0;
double first_sum_y = 0;
ros::Publisher y_ctrl_pub;  // 声明发布器为全局变量
struct YData {
    float y;
};
std::vector<YData> YDataBuffer;
bool isRecording = false;
/*
**************函数说明**************
1.订阅话题获取Y轴控制量
2.将Y轴控制量转化为电机真实控制量

*/
void yPubCallback(const std::vector<YData>& dataBuffer);
void yPositionCallback(const operating_ctrl::operating::ConstPtr& diff_msg) {
    ros::NodeHandle node;
    // 如果当前正在记录，添加数据到缓冲区
    if (isRecording) {
        YData data = {diff_msg->y2};
        YDataBuffer.push_back(data);
    }
    
    // 检测起始和结束标识符
    if (diff_msg->status == "KA" || diff_msg->status == "BA") 
    {
        // 添加包含 "KA&BA" 的那一帧数据到缓冲区
        YData data = {diff_msg->y2};
        YDataBuffer.push_back(data);  

        isRecording = true;
        
        
    } 
    else if (diff_msg->status == "KE" || diff_msg->status == "BE") 
    {
        // 如果当前正在记录，处理缓存的数据
        if(isRecording){
            isRecording = false;
            // 处理缓存的数据
            /*
            while(y_zhou_move != 1)
            {
                node.getParam("/y_zhou_move", y_zhou_move);
            }
            */
            
            yPubCallback(YDataBuffer);
            
        }
    }


}

void yPubCallback(const std::vector<YData>& dataBuffer)
{
    ros::NodeHandle node;
    operating_ctrl::y y_motor_angle_msg; // 在循环外部声明 Y 轴电机角度消息对象
    ROS_INFO("yzhou is working");  // 在 ROS 中打印信息，通常用于调试
    node.getParam("/first_y",first_y);    
    y_motor_angle_msg.y_motor_angle = (first_y * 60 / y_s / 5);
    first_sum_y += first_y;
    y_ctrl_pub.publish(y_motor_angle_msg);    
    ros::Duration(5.0).sleep();
    for (const auto& data : dataBuffer) 
    {
        float ctrl_y = data.y;

        // 计算整数部分和小数部分
        int y_motor_angle_integer = static_cast<int>(ctrl_y * 60 / y_s / T);
        double y_motor_angle_fraction = ctrl_y * 60 / y_s / T - y_motor_angle_integer;

        // 将小数部分累加到之前的累加值中
        y_motor_angle_accumulate += y_motor_angle_fraction;

        // 判断累加值是否大于等于1，如果是，则进行整数部分补偿
        if (y_motor_angle_accumulate >= 1.0)
        {
            y_motor_angle_integer += 1;
            y_motor_angle_accumulate -= 1.0;
        }

        // 创建消息对象并发布整数部分
        y_motor_angle_msg.y_motor_angle = y_motor_angle_integer;
        y_ctrl_pub.publish(y_motor_angle_msg);

        y_sum  += (y_motor_angle_integer); 
        ros::Duration(y_ctrl_pub_rate).sleep(); // 延时y_ctrl_pub_rate
    }
    // 在for循环结束后，设置消息的 Y 轴电机角度为0，以停止 Y 轴电机
    y_motor_angle_msg.y_motor_angle = 0;
    // 发布带有 Y 轴电机角度为0 的消息
    y_ctrl_pub.publish(y_motor_angle_msg);
    node.getParam("/now_is_kaicao_bufeng", now_is_kaicao_bufeng);
    if(now_is_kaicao_bufeng == 2)
    {
        y_motor_angle_msg.y_motor_angle =( (-1 * (y_sum ) * T ) + (-1 * first_sum_y * 60 / y_s) )/ 5;
        y_ctrl_pub.publish(y_motor_angle_msg);
        ros::Duration(5).sleep();
        y_motor_angle_msg.y_motor_angle = 0;
        y_ctrl_pub.publish(y_motor_angle_msg) ;
        y_sum = 0;       
    }
    // 清空 Y 轴数据缓冲区
    YDataBuffer.clear();
    
}


/*
**************函数说明**************
1.初始化ROS节点句柄
2.订阅operating_pub话题
3.创建话题y_ctrl_pub发布电机真实控制量
4.获取发布频率参数
*/
int main(int argc, char** argv) 
{
    //1.初始化ROS节点句柄
    ros::init(argc, argv, "y_ctrl");
    ros::NodeHandle node;
    double current_mode; // 存储 current_mode 的全局变量
    double last_mode;
    //2.订阅operating_pub话题
    ros::Subscriber sub_kaicao = node.subscribe<operating_ctrl::operating>("operating_kaicao", 10000, yPositionCallback);
    ros::Subscriber sub_bufeng = node.subscribe<operating_ctrl::operating>("operating_bufeng", 10000, yPositionCallback);
    
    //3.创建话题y_ctrl_pub发布电机真实控制量
    y_ctrl_pub = node.advertise<operating_ctrl::y>("y_ctrl_pub", 10000);  // 初始化发布器

    // 4.获取发布频率参数，如果没有指定，则设置默认值为 1



    while (ros::ok()) 
    {
        /*
        node.getParam("/current_mode", current_mode);
        //当前模式为扫描模式时，执行去干涉操作
        if (current_mode == 2 && current_mode != last_mode) 
        {
            last_mode = current_mode;
            std_msgs::Float32 ganshe_msg;
            ganshe_msg.data = y_operating_ganshe0 * 60 / y_s / T;
            y_ctrl_pub.publish(ganshe_msg);
            ros::Duration(10.0).sleep();//延时10 + 1 秒
            ganshe_msg.data = y_operating_ganshe1 * 60 / y_s / T;
            y_ctrl_pub.publish(ganshe_msg);
            ros::Duration(10.0).sleep();//延时10 + 1 秒
            ganshe_msg.data = 0;
            y_ctrl_pub.publish(ganshe_msg);
        }
        last_mode = current_mode;
        */
        ros::spinOnce(); // 处理回调函数
    }

    
    return 0;
}