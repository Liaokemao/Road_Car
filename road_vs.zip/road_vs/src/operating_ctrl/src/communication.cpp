#include "ros/ros.h"
#include "geometry_msgs/Pose2D.h"
#include "operating_ctrl/y.h"
#include "operating_ctrl/kaicao.h" 
#include "operating_ctrl/bufeng.h" 
#include "base_control/basecontrol.h" 
#include<iostream>
#include<thread>
#include<string>
#include<unistd.h>  
#include<fcntl.h>  
#include<termios.h> 
#include<sys/time.h>    
#include<modbus.h>
#include<fstream>
#include<vector>
#include<algorithm>
#include<signal.h>
#include<pthread.h>
#include <ros/ros.h>
#include <std_msgs/Bool.h>
#include "std_msgs/String.h"
#include "std_msgs/Int16.h"
#include "std_msgs/Float32.h"
#include <std_msgs/Float32.h>
#include <iomanip>
using namespace std;
int fangxianghuizheng = 0;
/////////////////********************************电机_ID
modbus_t* com;//com用于电机速度控制反馈，电机初始化
uint16_t fl_wheel_motor_r=0x01;//0x0A; //左前轮转向电机地址
uint16_t fr_wheel_motor_r=0x02;//0x0C; //右前轮转向电机地址
uint16_t rl_wheel_motor_r=0x03;//0x0E; //左后轮转向电机地址
uint16_t rr_wheel_motor_r=0x04;//0x10; //右后轮转向电机地址
uint16_t fl_wheel_motor_s=0x05; //左前轮驱动电机地址
uint16_t fr_wheel_motor_s=0x06; //右前轮驱动电机地址
uint16_t rl_wheel_motor_s=0x07; //左后轮驱动电机地址
uint16_t rr_wheel_motor_s=0x08; //右后轮驱动电机地址
uint16_t camera_motor_x=0x0A;//0x10; //相机扫描x方向电机地址
uint16_t camera_motor_y=0x09;//0x09; //相机扫描y方向电机地址
uint16_t control_motor_y=0x0B;//0x11; //Y轴方向驱动电机地址
uint16_t kaicao_motor_x=0x0C; //0x12;开槽X方向驱动电机地址
uint16_t bufeng_motor_x=0x0D; //0x13;补缝X方向驱动电机地址
uint16_t kaicao_motor_z=0x0E;//0x14;//开槽Z方向驱动电机地址
uint16_t bufeng_motor_z=0x0F; //0x15补缝Z方向驱动电机地址
uint16_t kaicao_motor_r=0x10; //0x16开槽旋转方向驱动电机地址
uint16_t bufeng_motor_r=0x11; //0x17补缝旋转方向驱动电机地址

/////////////////********************************功能码_ID
uint16_t readjicunqi=0x03;//功能码16#03：读取寄存器地址--------对应modbus_read_registers
uint16_t write_one=0x06;//功能码16#06：写入单个寄存器地址-------对应modbus_write_registers
uint16_t write_multi=0x0A;//功能码16#10：写入多个寄存器地址
//**************A IM otor系列电机位置模式参考**********************//
//控制模式选择//
uint16_t contorl_mode = 0x0200;//ID H02_00, 设置1为位置模式，设置0为速度模式
//力矩模式//
uint16_t lijumode = 0x0703; //ID H07_03,力矩值
//位置模式//
uint16_t position_threshold=0x0515;//ID H05_21 当这个差异小于或等于设定的阈值时，系统认为定位操作已经完成
uint16_t test_position1=0x110C;//ID H11_12 定位目标位置
uint16_t test_able_position1=0x0305;//ID H03_05 位置使能
uint16_t test_speed=0x110E;//ID H11_14 定位运行速度
uint16_t test_acc_time=0x110F;//ID H11_15 加减速度
uint16_t test_jieshu_time=0x1110;//ID H11_16 设置运行结束的等待时间
uint16_t test_able1=0x0303;//ID H03_03 设 1 电机使能导通；设 0 电机使能断开
uint16_t huiyuanmoshi=0x051E;//ID H05_30 设 6 设计电机原点,设5电机开始回原
//速度模式//
uint16_t test_vel=0x0603;//ID H06_03 定位目标位置
uint16_t vel_acc_time=0x0605;//ID H06_05 速度运行加速时间
uint16_t vel_dec_time=0x0606;//ID H06_06 速度运行减速时间
uint16_t vel_threshold=0x0515;//ID H05_21 当这个差异小于或等于设定的阈值时，系统认为速度已经到达
/////////////////**-****************定义函数**********************//
string port="/dev/ttyUSB2";//串口设备路径
bool openSerial(const char* port);//打开串口
void SetModbus(int motor1);//打开伺服电机
void position_control(int motor1,int speed);//位置控制输入
void position_mode(int motor1);//电机控制模式选择，位置模式
void vel_mode(int motor1);//电机模式选择，速度模式
void stopmotor(int motor1);//关闭伺服电机
void huiyuan(int motor1);//电机回原模式
void position_huiyuan(int motor1);
void vel_huiyuan_mode(int motor1);
void zhuanxiang_vel_mode(int motor1);
void liju_mode(int motor1);
void zhuanxiang_control(int motor1);
/////////////////******************打开串口**********************//
bool openSerial(const char* port)
{

    //
    com = modbus_new_rtu(port, 57600, 'N', 8, 2);// 波特率，“E”奇偶校验位，8:数据位,1:停止位
    if (com == nullptr)
    {
        cout << "wrong" << endl; // 电机异常警报
        return false;
    }
    struct timeval time_out;
    time_out.tv_sec = 0;
    time_out.tv_usec = 1 * 10; // 设置设备连接超时时间，单位微秒，假设为100ms
    modbus_set_response_timeout(com, &time_out);
    modbus_rtu_set_serial_mode(com, MODBUS_RTU_RS485); // 设置 MODBUS 串口为 RS485
    if (modbus_connect(com) == -1) // 连接 MODBUS 设备
    {
        cout << "connot connect modbus at port " << port << endl;
        return false;
    }
    else
        cout << "Comunication_node:已连接端口为 " << port << " 的 modbus 设备。" << endl;
    return true;
}


///////////////////////////************电机伺服打开*************//////////////////
void SetModbus(int motor1)
{
    const uint16_t src0[] = {0x0000};    // 
    const uint16_t src1[] = {0x0001};  // 写入寄存器的数据
    modbus_set_slave(com, motor1); // 设置 Modbus 设备地址
    modbus_write_registers(com, test_able1, 1, src1);     // 伺服电机使能
    
}
void ReadModbus(int motor1) {
    uint16_t read_addr_low = 0x0B07; // 低32位绝对编码器位置
    const uint16_t src0[] = {0x0000};
    uint16_t temp[1]; // 用于存储读取到的寄存器值的数组
    modbus_set_slave(com, motor1);
    modbus_read_registers(com, read_addr_low, 1, temp); // 读取寄存器数据到 temp 数组中


    usleep(2000); // 稍微延迟一段时间
    printf("%04X\n", temp[0]);
    int velocity0 = 0;
    uint16_t velocity2[]= {(uint16_t)velocity0};//把话题获取的转速数据转化为16进制
    /*
    if (temp > 10000 ||temp < -10000 )
    
    {
        modbus_write_registers(com, test_able1, 1, src0);     // 伺服电机失能
        ros::Duration(0.5).sleep();
        modbus_write_registers(com,test_vel,1,velocity2); //速度归零
        ros::param::set("/chaoxingcheng",1);
    }
    */
}
///////////////////////////************电机关机*************//////////////////
void stopmotor(int motor1)
{
    const uint16_t src0[]={0x00};    //
    const uint16_t src1[]={0x00};    //写入寄存器的数据
    modbus_set_slave(com,motor1); 
    modbus_write_registers(com,test_able1,1,src1); //伺服电机使能，低八位 
}

//////////////////////////************电机控制模式*************//////////////////
//位置模式
void position_mode(int motor1)
{
    const uint16_t src0[] = {0x0000};    // 
    const uint16_t src1[] = {0x0001};  // 写入寄存器的数据
    const uint16_t huiyuan0[] = {0x0005};
    modbus_set_slave(com,motor1); //设置modbus设备地址
    modbus_write_registers(com, test_able1, 1, src0);     // 伺服电机失能
    modbus_write_registers(com, contorl_mode , 1, src1);     //伺服模式选择，1位置模式，0速度模式，设置位置控制模式
    modbus_write_registers(com, test_able1, 1, src1);     // 伺服电机失能
}
void zhixing_position_mode(int motor1)
{
    const uint16_t src0[] = {0x0000};    // 
    const uint16_t src1[] = {0x0001};  // 写入寄存器的数据
    const uint16_t huiyuan0[] = {0x0005};
    modbus_set_slave(com,motor1); //设置modbus设备地址 
    modbus_write_registers(com, test_able_position1, 1, src0);
    modbus_write_registers(com, test_able1, 1, src0);     // 伺服电机失能
    modbus_write_registers(com, contorl_mode , 1, src1);     //伺服模式选择，1位置模式，0速度模式，设置位置控制模式
    modbus_write_registers(com, test_able1, 1, src1);     
    modbus_write_registers(com, test_able_position1, 1, src1);
}
//速度模式
void vel_mode(int motor1)
{
    const uint16_t src0[] = {0x0000};    // 
    const uint16_t src1[] = {0x0001};  // 写入寄存器的数据
    const uint16_t huiyuan0[] = {0x0006};
    modbus_set_slave(com,motor1); //设置modbus设备地址
    modbus_write_registers(com, test_able1, 1, src0);     // 伺服电机失能
    
    modbus_write_registers(com, contorl_mode , 1, src0);     //伺服模式选择，1位置模式，0速度模式，设置速度控制模式
    
    modbus_write_registers(com, test_able1, 1, src1);     // 伺服电机使能
}
//速度回原模式
void vel_huiyuan_mode(int motor1)
{
    const uint16_t src0[] = {0x0000};    // 
    const uint16_t src1[] = {0x0001};  // 写入寄存器的数据
    const uint16_t huiyuan0[] = {0x0005};
    modbus_set_slave(com,motor1); //设置modbus设备地址
    modbus_write_registers(com, test_able1, 1, src0);     // 伺服电机失能
    
    modbus_write_registers(com, contorl_mode , 1, src1);     //伺服模式选择，1位置模式，0速度模式，设置位置控制模式
    
    modbus_write_registers(com, test_able1, 1, src1);     // 伺服电机使能
     
    modbus_write_registers(com, huiyuanmoshi, 1, huiyuan0); //回原模式，上电回到原点，设置5
    ros::Duration(5).sleep();
    modbus_write_registers(com, test_able1, 1, src0);     // 伺服电机失能
    
    modbus_write_registers(com, contorl_mode , 1, src0);     //伺服模式选择，1位置模式，0速度模式，设置速度控制模式
    
    modbus_write_registers(com, test_able1, 1, src1);     // 伺服电机使能
}
//转向电机
void zhuanxiang_vel_mode(int motor1)
{
    const uint16_t src0[] = {0x0000};    // 
    const uint16_t src1[] = {0x0001};  // 写入寄存器的数据
    const uint16_t huiyuan0[] = {0x0005};
    modbus_set_slave(com,motor1); //设置modbus设备地址
    modbus_write_registers(com, test_able1, 1, src0);     // 伺服电机失能
    
    modbus_write_registers(com, contorl_mode , 1, src1);     //伺服模式选择，1位置模式，0速度模式，设置位置控制模式
    
    modbus_write_registers(com, test_able1, 1, src1);     // 伺服电机使能
     
    modbus_write_registers(com, huiyuanmoshi, 1, huiyuan0);//回原模式，上电回到原点，设置5
    ros::Duration(3).sleep();
    modbus_write_registers(com, test_able1, 1, src0);     // 伺服电机失能
    modbus_write_registers(com, test_able1, 1, src1);     // 伺服电机失能    
}
void liju_mode(int motor1)
{
    const uint16_t src0[] = {0x0000};    // 
    const uint16_t src1[] = {0x0002};  // 写入寄存器的数据
    const uint16_t ssr0[] = {0x001E};
    modbus_set_slave(com,motor1); //设置modbus设备地址
    modbus_write_registers(com, test_able1, 1, src0);     // 伺服电机失能
    
    modbus_write_registers(com, contorl_mode , 1, src1);     //伺服模式选择，1位置模式，0速度模式，设置力矩控制模式
    
    modbus_write_registers(com, test_able1, 1, src1);     // 伺服电机使能
    
    modbus_write_registers(com, lijumode, 1, ssr0);
    ros::Duration(20).sleep();    
    modbus_write_registers(com, test_able1, 1, src0);     // 伺服电机失能
}
//****************************************************************************************
///////////////////////////************电机位置控制*************//////////////////
void position_control(int motor1, int position)
{
    uint16_t position_able0[] = {0x0000};     
    uint16_t position_able1[] = {0x0001};    
    const uint16_t src0[] = {0x0000};    // 
    const uint16_t src1[] = {0x0001};  // 写入寄存器的数据
    uint16_t position1[2]; // 高位和低位 // 将话题获取的位置数据转化为16进制//最大值为65535  
    
    if (position >= 0)
    {
        // 左转
        // 处理负数
        position1[0] = position;
        position1[1] = 0x0000;
        // 输出Modbus RTU帧的16进制表示
        modbus_set_slave(com, motor1);
        modbus_write_registers(com, test_able_position1, 1, position_able0);
        modbus_write_registers(com, test_position1, 2, position1);   // 发出位置指令，低八位 test_able_position1

    }
    else if (position < 0)
    {
        // 处理负数
        position1[0] = 0xFFFF + 1 + position;
        position1[1] = 0xFFFF;
        modbus_set_slave(com, motor1);
        modbus_write_registers(com, test_able_position1, 1, position_able0);
        modbus_write_registers(com, test_position1, 2, position1);        
    }
}
void zhuanxiang_control(int motor1)
{
    uint16_t position_able0[] = {0x0000};     
    uint16_t position_able1[] = {0x0001};
    modbus_set_slave(com, motor1);    
    modbus_write_registers(com, test_able_position1, 1, position_able1);
}
///////////////////////////************电机速度控制*************//////////////////
void velocity_control(int motor1,int velocity)
{
    if(velocity>0)
    {
        //左转
        uint16_t velocity1[]= {(uint16_t)velocity};//把话题获取的转速数据转化为16进制
        modbus_set_slave(com,motor1); 
        modbus_write_registers(com,test_vel,1,velocity1);      // 发出速度指令
    }
    else
    {
        //右转
        velocity =-velocity;
        velocity = 65535-velocity+1;
        uint16_t velocity1[]= {(uint16_t)velocity};//把话题获取的转速数据转化为16进制
        modbus_set_slave(com,motor1); 
        modbus_write_registers(com,test_vel,1,velocity1);
    }
}
///////////////////////////************回原模式*************//////////////////
void position_huiyuan(int motor1)
{
    const uint16_t src0[] = {0x0000};    // 
    const uint16_t src1[] = {0x0001};  // 写入寄存器的数据
    const uint16_t huiyuan0[] = {0x0005};
    modbus_set_slave(com,motor1); //设置modbus设备地址
    modbus_write_registers(com, test_able_position1, 1, src0);
    modbus_write_registers(com, huiyuanmoshi, 1, huiyuan0);//回原模式，上电回到原点，设置5
}
void shutdownCallback() 
{
    int dianjitiaoling = 0;                                
    
    velocity_control(fl_wheel_motor_s,dianjitiaoling);                                
    
    velocity_control(fr_wheel_motor_s,dianjitiaoling);                               
    
    velocity_control(rl_wheel_motor_s,dianjitiaoling);                                
    
    velocity_control(rr_wheel_motor_s,dianjitiaoling);                
                                    
    stopmotor(camera_motor_x);//失能电机
     
    stopmotor(camera_motor_y);//失能电机
         
    stopmotor(control_motor_y);//失能电机
      
    stopmotor(kaicao_motor_z);//失能电机
      
    stopmotor(kaicao_motor_x);//失能电机
      
    stopmotor(kaicao_motor_r);//失能电机
      
    stopmotor(bufeng_motor_z);//失能电机
      
    stopmotor(bufeng_motor_x);//失能电机
      
    stopmotor(bufeng_motor_r);//失能电机
      
    stopmotor(fl_wheel_motor_r);//失能电机
      
    stopmotor(fl_wheel_motor_s);//失能电机
      
    stopmotor(fr_wheel_motor_r);//失能电机
      
    stopmotor(fr_wheel_motor_s);//失能电机
      
    stopmotor(rl_wheel_motor_r);//失能电机
      
    stopmotor(rl_wheel_motor_s);//失能电机
      
    stopmotor(rr_wheel_motor_r);//失能电机
      
    stopmotor(rr_wheel_motor_s);//失能电机
    modbus_free(com);
}
///////////////////////////************订阅话题*************//////////////////

class Communication {
private:
    ros::NodeHandle nh;
    ros::Subscriber cam_ctrl_sub;
    ros::Subscriber y_ctrl_sub;
    ros::Subscriber kaicao_pub_sub;
    ros::Subscriber bufeng_pub_sub;
    ros::Subscriber control_sub;
    ros::Subscriber control_sub2;
    ros::Subscriber kaicao_z_pub_sub;
    ros::Subscriber bufeng_z_pub_sub;
public:
    Communication() {
        cam_ctrl_sub = nh.subscribe("cam_ctrl_pub", 1000, &Communication::scanCallback, this);
        y_ctrl_sub = nh.subscribe<operating_ctrl::y>("y_ctrl_pub", 10000, &Communication::ycontrolCallback, this);
        kaicao_pub_sub = nh.subscribe<operating_ctrl::kaicao>("kaicao_pub", 10000, &Communication::kaicaoCallback, this);
        kaicao_z_pub_sub = nh.subscribe("kaicao_z_pub", 1000, &Communication::kaicao_z_Callback, this);        
        bufeng_pub_sub = nh.subscribe<operating_ctrl::bufeng>("bufeng_pub", 10000, &Communication::bufengCallback, this);
        bufeng_z_pub_sub = nh.subscribe("bufeng_z_pub", 1000, &Communication::bufeng_z_Callback, this);
        //control_sub2 = nh.subscribe<base_control::basecontrol>("/control_topic", 1000, &Communication::basecontrolCallback2, this);
        control_sub = nh.subscribe<base_control::basecontrol>("/control_topic", 1000, &Communication::basecontrolCallback, this);

    }

//扫描模式，x，y两个电机
void scanCallback(const geometry_msgs::Pose2D::ConstPtr& msg) {
    int scan_x = msg->x;
    int scan_y = msg->y;
    position_control(camera_motor_x,scan_x); 
    position_control(camera_motor_y,scan_y);
    zhuanxiang_control(camera_motor_x); 
    zhuanxiang_control(camera_motor_y);
}
//y轴移动，1个电机
void ycontrolCallback(const operating_ctrl::y::ConstPtr& msg) {
    int y_motor_angle = msg->y_motor_angle;
    velocity_control(control_motor_y,y_motor_angle);
}
//开槽模组，x，z，theta三个电机
void kaicaoCallback(const operating_ctrl::kaicao::ConstPtr& msg) {
    int kaicao_x_motor_angle = msg->kaicao_x_motor_angle;
    int kaicao_theta_motor_angle = msg->kaicao_theta_motor_angle;
    position_control(kaicao_motor_r,kaicao_theta_motor_angle);
    velocity_control(kaicao_motor_x,kaicao_x_motor_angle);
    zhuanxiang_control(kaicao_motor_r);
}
void kaicao_z_Callback(const std_msgs::Float32::ConstPtr& msg) {
    int kaicao_z_motor_angle = msg->data;
    //position_control(kaicao_motor_z,kaicao_z_motor_angle);
    //zhuanxiang_control(kaicao_motor_z);
}
//补缝模组，x，z，theta三个电机
void bufengCallback(const operating_ctrl::bufeng::ConstPtr& msg) {
    int bufeng_x_motor_angle = msg->bufeng_x_motor_angle;
    int bufeng_theta_motor_angle = msg->bufeng_theta_motor_angle;
    velocity_control(bufeng_motor_x,bufeng_x_motor_angle);
    //velocity_control(bufeng_motor_r,bufeng_theta_motor_angle);
}
void bufeng_z_Callback(const std_msgs::Float32::ConstPtr& msg) {
    int bufeng_z_motor_angle = msg->data;
    //position_control(bufeng_motor_z,bufeng_z_motor_angle);
    //zhuanxiang_control(bufeng_motor_z);
}
//底盘模组，四个驱动，四个转动，一共八个电机
void basecontrolCallback(const base_control::basecontrol::ConstPtr& control_msg) {
    
    int Angel_motor_fl = control_msg->Angel_motor_fl;
    int Angel_motor_rl = control_msg->Angel_motor_rl;
    int Angel_motor_fr = control_msg->Angel_motor_fr;
    int Angel_motor_rr = control_msg->Angel_motor_rr;
    int Vel_motor_fl = control_msg->Vel_motor_fl;
    int Vel_motor_rl = control_msg->Vel_motor_rl;
    int Vel_motor_fr = control_msg->Vel_motor_fr;
    int Vel_motor_rr = control_msg->Vel_motor_rr;  
    position_control(fl_wheel_motor_r,Angel_motor_fl);
    position_control(fr_wheel_motor_r,Angel_motor_fr);
    position_control(rl_wheel_motor_r,Angel_motor_rl); 
    position_control(rr_wheel_motor_r,Angel_motor_rr);
    zhuanxiang_control(fl_wheel_motor_r); 
    zhuanxiang_control(fr_wheel_motor_r); 
    zhuanxiang_control(rl_wheel_motor_r);
    zhuanxiang_control(rr_wheel_motor_r); 
    velocity_control(fl_wheel_motor_s,Vel_motor_fl);  
    velocity_control(fr_wheel_motor_s,Vel_motor_fr);     
    velocity_control(rl_wheel_motor_s,Vel_motor_rl); 
    velocity_control(rr_wheel_motor_s,Vel_motor_rr); 
}

};
//主函数
int main(int argc, char **argv) {
    ros::init(argc, argv, "communication");
    ros::NodeHandle nh;
    Communication pub;
    openSerial(port.c_str());
    //modbus_free(com);
    position_mode(camera_motor_x);//位置控制
    position_mode(camera_motor_y);//位置控制
    //ROS_INFO_STREAM("11111");
    vel_mode(control_motor_y);//速度回原控制
    //position_mode(kaicao_motor_z);//位置控制
    vel_mode(kaicao_motor_x);//速度回原控制/
    position_mode(kaicao_motor_r);//速度回原控制
    //position_mode(bufeng_motor_z);//位置控制
    vel_mode(bufeng_motor_x);//速度回原控制
    //position_mode(bufeng_motor_r);//速度回原控制

    zhuanxiang_vel_mode(fl_wheel_motor_r);//位置控制
    vel_mode(fl_wheel_motor_s);//速度控制
    zhuanxiang_vel_mode(fr_wheel_motor_r);//位置控制
    vel_mode(fr_wheel_motor_s);//速度控制
    zhuanxiang_vel_mode(rl_wheel_motor_r);//位置控制
    vel_mode(rl_wheel_motor_s);//速度控制
    zhuanxiang_vel_mode(rr_wheel_motor_r);//位置控制
    vel_mode(rr_wheel_motor_s);//速度控制
    ROS_INFO_STREAM("CHU SHI HUA CHENGGONG");
 ///////////////////////////************检测当前模式*************//////////////////
    int last_mode = -1;
    int shutdown;
    int current_mode;
    int last_now_is_kaicao_bufeng = -1;
    int now_is_kaicao_bufeng;
    ros::Rate loop_rate(10000);
    while (ros::ok()) {
        ros::spinOnce(); // 处理回调函数

        nh.getParam("/current_mode", current_mode); // 从参数服务器获取当前模式的值
        nh.getParam("/shutdown",shutdown);
        nh.getParam("/now_is_kaicao_bufeng",now_is_kaicao_bufeng);
        if(shutdown == 1)
        {
            ros::shutdown();
            break;
        }
        if (nh.getParam("/fangxianghuizheng", fangxianghuizheng))
        if (fangxianghuizheng == 1)
        {
            zhuanxiang_vel_mode(fl_wheel_motor_r);
            zhuanxiang_vel_mode(fr_wheel_motor_r);
            zhuanxiang_vel_mode(rl_wheel_motor_r);
            zhuanxiang_vel_mode(rr_wheel_motor_r);
            ros::param::set("/fangxianghuizheng",2); 
            break;           
        }
        
        if (current_mode != last_mode) {
            last_mode = current_mode;
            // 只有当当前模式与上一个模式不同时才执行相应的操作
            switch(current_mode)
            {
                case 4: 
                        zhixing_position_mode(kaicao_motor_x);
                        zhixing_position_mode(bufeng_motor_x);
                        zhixing_position_mode(control_motor_y);
                        ros::Duration(2).sleep();
                        vel_mode(kaicao_motor_x);//速度回原控制/
                        vel_mode(control_motor_y);//速度回原控制
                        vel_mode(bufeng_motor_x);//速度回原控制
                        ROS_INFO_STREAM("zhixing fuwei"); 
                default:
                        break;
            }
        }
        
        loop_rate.sleep(); // 控制循环频率
    }
    shutdownCallback();
    return 0;
}