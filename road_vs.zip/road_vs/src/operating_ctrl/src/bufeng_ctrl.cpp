/*
***************程序说明***************
本程序作业模式，根据局部相机提供的裂缝消息，转化为补缝的控制指令
程序实现步骤: 1.void bufengCallback（）实现计算和发布电机真实控制量
            2.int main（）ros主函数
*/
#include "ros/ros.h"
#include "operating_ctrl/operating.h"
#include "operating_ctrl/bufeng.h"
#include <std_msgs/Float32.h>
#include <string>
double bufeng_x_s = 5;  // 补缝x方向电机导程，给定的常数值，单位mm
double bufeng_theta_s = 23.333333;// 补缝theta方向电机导程，给定的常数值，单位mm
double bufeng_z_s = 5; // 补缝z方向电机导程，给定的常数值，单位mm
double bufeng_z_angle = 1;//补缝z方向下降高度，给定的常数值，单位mm
double bufeng_z_back =0;//补缝z方向提起高度，给定的常数值，单位mm
double bufeng_theta_0 =0;
double bufeng_x_center = -200;
double bufeng_r_center = 0;
double bufeng_z_motor_angle;
double sum_bufeng_x = 0;
double sum_bufeng_r = 0;
double first_bufeng_x = 0;
double first_bufeng_theta = 0;
double first_y = 0;
// 设置循环次数
int bufeng_step = 0;
// 在循环外部定义变量保存小数部分的累加值
double bufeng_x_motor_angle_accumulate = 0.0;
double bufeng_theta_motor_angle_accumulate = 0.0;
double bufeng_pub_rate=1;
double A = 1000; //分辨率
double T=1;//运动时间间隔
ros::Publisher bufeng_pub;
ros::Publisher bufeng_z_pub;
struct BufengData {
    float x;
    float theta;
};
std::vector<BufengData> bufengDataBuffer;
bool isRecording = false;

/*
**************函数说明**************
1.订阅话题获取补缝x,d,theta控制量
2.将补缝x,d,theta控制量转化为电机真实控制量
3.创建话题bufeng_pub发布电机真实控制量
*/
void bufengCallback(const std::vector<BufengData>& dataBuffer);

void bufengPositionCallback(const operating_ctrl::operating::ConstPtr& diff_msg) {
    ros::NodeHandle node;
    operating_ctrl::bufeng bufeng_pub_msg;
    // 如果当前正在记录，添加数据到缓冲区
    if (isRecording) {
        BufengData data = {diff_msg->x2, diff_msg->theta2};
        bufengDataBuffer.push_back(data);
    }
    
    // 检测起始和结束标识符
    if (diff_msg->status == "BA") 
    {
        // 添加包含 "KA" 的那一帧数据到缓冲区
        BufengData data = {diff_msg->x2, diff_msg->theta2};
        bufengDataBuffer.push_back(data);
        
        isRecording = true;

        

    } 
    else if (diff_msg->status == "BE") 
    {
        // 如果当前正在记录，处理缓存的数据
        if (isRecording) {
            isRecording = false;
            bufengCallback(bufengDataBuffer);
        }
    }


}



void bufengCallback(const std::vector<BufengData>& dataBuffer) 
{
    ros::NodeHandle node;
    operating_ctrl::bufeng bufeng_pub_msg;//创建话题信息发布
    ROS_INFO("bufeng is working");
    node.getParam("/first_bufeng_x",first_bufeng_x);
    node.getParam("/first_bufeng_theta",first_bufeng_theta);
    bufeng_pub_msg.bufeng_x_motor_angle = (first_bufeng_x + bufeng_x_center) * 60 / bufeng_x_s / 5;
    bufeng_pub_msg.bufeng_theta_motor_angle = first_bufeng_theta * bufeng_theta_s * 1000 / 360;
    bufeng_pub.publish(bufeng_pub_msg);
    ros::Duration(5.0).sleep();
        //作业开始时，设置z电机角度为0.3，以下降z轴
    bufeng_z_angle = 0.3;
    bufeng_z_motor_angle = bufeng_z_angle / bufeng_z_s * A;
    std_msgs::Float32 z_msg;
    z_msg.data = bufeng_z_motor_angle;
    bufeng_z_pub.publish(z_msg);
    node.setParam("/now_is_kaicao_bufeng", 2);
    //1.订阅话题获取补缝x,d,theta控制量
    for (const auto& data : dataBuffer) 
    {
        float bufeng_x = data.x;
        float bufeng_theta = data.theta;

        // 计算整数部分和小数部分
        int bufeng_x_motor_angle_integer = static_cast<int>(bufeng_x * 60 / bufeng_x_s / T);
        int bufeng_theta_motor_angle_integer = static_cast<int>(bufeng_theta * bufeng_theta_s * 1000 / 360);

        double bufeng_x_motor_angle_fraction = bufeng_x * 60 / bufeng_x_s / T - bufeng_x_motor_angle_integer;
        double bufeng_theta_motor_angle_fraction = (bufeng_theta * bufeng_theta_s * 1000 / 360) - bufeng_theta_motor_angle_integer;

        // 将小数部分累加到之前的累加值中
        bufeng_x_motor_angle_accumulate += bufeng_x_motor_angle_fraction;
        bufeng_theta_motor_angle_accumulate += bufeng_theta_motor_angle_fraction;

        // 判断累加值是否大于等于1，如果是，则进行整数部分补偿
        if (bufeng_x_motor_angle_accumulate >= 1.0)
        {
            bufeng_x_motor_angle_integer += 1;
            bufeng_x_motor_angle_accumulate -= 1.0;
        }

        if (bufeng_theta_motor_angle_accumulate >= 1.0)
        {
            bufeng_theta_motor_angle_integer += 1;
            bufeng_theta_motor_angle_accumulate -= 1.0;
        }

        // 创建话题并发布整数部分
        bufeng_pub_msg.bufeng_x_motor_angle = bufeng_x_motor_angle_integer;
        bufeng_pub_msg.bufeng_theta_motor_angle = bufeng_theta_motor_angle_integer;
        bufeng_pub.publish(bufeng_pub_msg);
        sum_bufeng_x += bufeng_x_motor_angle_integer;
        sum_bufeng_r += bufeng_theta_motor_angle_integer;
        ros::Duration(bufeng_pub_rate).sleep(); // 延时bufeng_pub_rate
        // 增加 bufeng_step
        bufeng_step++;
        // 设置新值
        //node.setParam("/bufeng_step", bufeng_step);
    }
    bufeng_step = 0;
    //5.作业结束后，设置z电机角度为-0.3，以提起z轴    
    bufeng_z_back =-0.3;
    bufeng_z_motor_angle = bufeng_z_back / bufeng_z_s * A;
    z_msg.data = bufeng_z_motor_angle;
    bufeng_z_pub.publish(z_msg);
    //4.for循环结束后，设置x，theta电机角度为0，以停止x，theta电机
    bufeng_pub_msg.bufeng_x_motor_angle = (-1 * sum_bufeng_x * T + (-1 * (bufeng_x_center + first_bufeng_x) * 60 / bufeng_x_s)) / 5;
    bufeng_pub_msg.bufeng_theta_motor_angle = 0;
    bufeng_pub.publish(bufeng_pub_msg);
    ros::Duration(5).sleep();
    bufeng_pub_msg.bufeng_x_motor_angle = 0;
    bufeng_pub_msg.bufeng_theta_motor_angle = 0;
    bufeng_pub.publish(bufeng_pub_msg);
    bufengDataBuffer.clear();  // 清除旧数据
    ros::Duration(5).sleep();
    node.setParam("/current_mode", 3);

    sum_bufeng_x = 0;
    sum_bufeng_r = 0;
    //node.setParam("/current_mode", 0); 
}
/*
**************函数说明**************
1.初始化ROS节点句柄
2.订阅operating_bufeng话题
3.发布bufeng_pub话题
4.bufeng_pub_rate挂载参数服务器
*/
int main(int argc, char** argv) 
{
    //1.初始化ROS节点句柄
    ros::init(argc, argv, "bufeng_ctrl");
    ros::NodeHandle node;
    node.param("/bufeng_z_angle", bufeng_z_angle, 1.0); // 默认值为1
    //2.订阅operating_bufeng话题
    ros::Subscriber sub = node.subscribe("operating_bufeng", 100000, bufengPositionCallback);
    //3.发布bufeng_pub话题
    bufeng_pub = node.advertise<operating_ctrl::bufeng>("bufeng_pub", 100000);
    bufeng_z_pub = node.advertise<std_msgs::Float32>("/bufeng_z_pub", 100000);


    while (ros::ok()) 
    {
        ros::spinOnce();
        // 在循环中添加以下行以控制循环频率
    }

    return 0;
}