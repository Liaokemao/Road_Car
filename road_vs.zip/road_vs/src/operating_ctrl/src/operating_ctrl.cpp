/*
***************程序说明***************
本程序作业模式，根据局部相机提供的裂缝消息，分配给y轴，补缝模块，开槽模块控制指令
程序实现步骤: 1.void kaicaochabuyunsuan() 进行开槽作业点插补计算
            2.void bufengchabuyunsuan()进行补缝作业点插补计算 
            3.void localPositionCallback() 订阅话题，处理消息
            4.int main（）主函数
*/
#include "ros/ros.h"
#include "operating_ctrl/operating.h"
#include "operating_ctrl/custommessage.h"
#include "ssr_pkg/custommessage.h"
#include <vector>
#include <cmath>
#include <iostream>
int now_is_kaicao_bufeng = -1;
//定义Position变量
struct Position {
    float x0;
    float y0;
};
float operating_x1 = 0.0;  // 初始化
float operating_y1 = 0.0;  // 初始化
float operating_theta1 = 0.0;
float accumulated_x = 0.0;
float accumulated_y = 0.0;
float accumulated_theta0 = 0.0; // 初始化累加的角度值为0
float accumulated_theta1 = 0.0; // 初始化累加的角度值为0
float accumulated_theta = 0.0;
int yaokaicao = 1;
int bukaicao = 0;
int numPoints2 = 1;       // 插值点数量
ros::Publisher operating_kaicao;// 全局 Publisher
ros::Publisher operating_bufeng;// 全局 Publisher
std::vector<Position> positionBuffer;  // 用于存储local_position数据
bool isRecording = false;  // 是否开始记录数据
bool kaicao_or_bufeng = false;//是否开槽
int pos_index = -1;//初始化数据数量
int kaicao_bufeng = 0; // 开槽，补缝工作切换参数
int only_kaicao_or_bufeng = -1;
void kaicaochabuyunsuan() 
{

    pos_index = 0; // 重置变量
    std::vector<operating_ctrl::operating> messages;
    ros::NodeHandle node;
    bool kaicaoPublished = false;  // 显式将变量初始化为 false

    // 首先生成所有的消息并存储起来
    if (!positionBuffer.empty()) 
    {
        //const int lastPositionIndex = positionBuffer.size() - 1;
        
        for (int i = 1; i < positionBuffer.size(); ++i) //进行插补计算
        {
            const Position& pos = positionBuffer[i];
            float x2 = pos.x0 - operating_x1; //计算x变化值
            float y2 = pos.y0 - operating_y1; //计算y变化值
            float theta2 = 90 - (std::atan2(pos.y0, pos.x0) * 180.0 / M_PI); // 计算角度变化值
            float theta0 = 90 - (std::atan2(y2, x2) * 180.0 / M_PI) - operating_theta1; // 计算角度变化值            
            accumulated_theta0 += theta0; // 将当前角度变化值累加到总和中
            float dx2 = x2 / numPoints2; //计算x插值
            float dy2 = y2 / numPoints2; //计算y插值
            float dtheta2 = theta2 / numPoints2; //计算角度插值
            
            for (int j = 0; j < numPoints2; ++j) //发布插值消息
            {
                operating_ctrl::operating diff_msg;
                diff_msg.x2 = dx2;
                diff_msg.y2 = dy2;
                diff_msg.theta2 = dtheta2;

                // 添加开始和结束标识符
                if (i == 1 && j == 0) {
                    diff_msg.status = "KA"; // 开始标识符
                } else if (i == positionBuffer.size() - 1 && j == numPoints2 - 1) {
                    diff_msg.status = "KE"; // 结束标识符
                } else {
                    diff_msg.status = ""; // 中间消息没有标识符
                }
                messages.push_back(diff_msg);
            }
            pos_index++; // 更新 pos_index
            operating_x1 = pos.x0;
            operating_y1 = pos.y0;
            operating_theta1 = 90 - (std::atan2(y2, x2) * 180.0 / M_PI);
            node.getParam("/kaicao_bufeng", kaicao_bufeng);
        }
            accumulated_theta1 = accumulated_theta0;
        // 通过operating_kaicao话题发布所有消息
        if (kaicao_bufeng == 0) 
        {
            for (const auto& msg : messages) 
            {
                operating_kaicao.publish(msg);
                ros::spinOnce(); // 确保消息得到处理
            }
            ROS_INFO("All messages published on operating_kaicao");
        }  
        //当开槽消息发布并处理后，执行补缝作业，将/kaicao_bufeng置1
    node.setParam("/kaicao_bufeng", 1);
    node.setParam("/now_is_kaicao_bufeng", 0);
    node.getParam("/kaicao_bufeng", kaicao_bufeng);
    node.getParam("/now_is_kaicao_bufeng", now_is_kaicao_bufeng);
    kaicaoPublished = true;// 在发布operating_kaicao后将标志设置为true
    // 通过operating_bufeng话题再次发布这些消息
    while (kaicaoPublished) 
    {
        // 重置变量
        pos_index = 0;
        // 清空原有messages，并重新计算插值
        messages.clear();
        // 检查是否有至少两个元素在 positionBuffer 中
        if (positionBuffer.size() >= 2) {
            // 获取 positionBuffer 中的倒数第二个元素的 x0 值，并赋值给 accumulated_x
            accumulated_x = positionBuffer[positionBuffer.size() - 1].x0;
        }
        // 检查是否有元素在 positionBuffer 中
        if (positionBuffer.size() >= 2) {
            // 获取 positionBuffer 中的倒数第二个元素的 x0 值，并赋值给 accumulated_x
            accumulated_y = positionBuffer[positionBuffer.size() - 1].y0;
        }
            accumulated_theta = 90 - (std::atan2(accumulated_y, accumulated_x) * 180.0 / M_PI);
        std::reverse(positionBuffer.begin(), positionBuffer.end()); // 反转positionBuffer
        // 计算反转positionBuffer中所有pos.x0的累加值


        // 重新进行插值计算
        for (int i = 1; i < positionBuffer.size(); ++i) 
        {
            const Position& pos = positionBuffer[i];
            float x2 = pos.x0 - operating_x1; //计算x变化值
            float y2 = pos.y0 - operating_y1; //计算y变化值 
            float theta2 = 90 - (std::atan2(pos.y0, pos.x0) * 180.0 / M_PI); 
            /*
            if (theta1 > 90)
            {
                theta1 = (theta1 - 90);
            }else if (theta1 <= 90)
            {
                theta1 = (90  - theta1);
            }
            
            float theta2 = theta1;
            */
            //float theta2 = -(std::atan2(-y2, -x2) * 180.0 / M_PI);  // 计算角度变化值
            float dx2 = x2 / numPoints2; //计算x插值
            float dy2 = y2 / numPoints2; //计算y插值
            float dtheta2 = theta2 / numPoints2; //计算theta插值
            ros::param::set("/first_bufeng_theta",accumulated_theta);
            for (int j = 0; j < numPoints2; ++j) //发布插值消息
            {
                operating_ctrl::operating diff_msg;
                diff_msg.x2 = dx2;
                diff_msg.y2 = dy2;
                diff_msg.theta2 = dtheta2;

                // 添加开始和结束标识符
                if (i == 1 && j == 0) {
                    diff_msg.status = "BA";  // 开始标识符
                    diff_msg.x2 = accumulated_x;
                    diff_msg.y2 = 0;
                    diff_msg.theta2 = accumulated_theta;
                } else if (i == positionBuffer.size() - 1 && j == numPoints2 - 1) {
                    diff_msg.status = "BE";  // 结束标识符
                } else {
                    diff_msg.status = "";  // 中间消息没有标识符
                }
                messages.push_back(diff_msg);
            }
            pos_index++;  // 更新 pos_index
            operating_x1 = pos.x0;
            operating_y1 = pos.y0;
            operating_theta1 = 90 - (std::atan2(y2, x2) * 180.0 / M_PI);
        }  
        while (now_is_kaicao_bufeng != 1) 
        {
            node.getParam("/now_is_kaicao_bufeng", now_is_kaicao_bufeng);
        } 
        ros::Duration(1.0).sleep();
        // 发布到operating_bufeng话题
        for (const auto& msg : messages) 
        {
            operating_bufeng.publish(msg);
            ros::spinOnce(); // 确保消息得到处理 
        }
        accumulated_x = 0;
        accumulated_y = 0;
        accumulated_theta1 = 0;
        accumulated_theta0 = 0;
        ROS_INFO("All messages published on operating_bufeng");


        messages.clear(); // 消息发布完后清除缓存区
        node.setParam("/kaicao_bufeng", 0); // 重新置kaicao_bufeng为0
        kaicaoPublished = false;  // 在发布operating_bufeng后将标志设置为false
        operating_x1 = 0;
        operating_y1 = 0;
        operating_theta1 = 0;
 
    }   
}
}

void bufengchabuyunsuan() 
{
    std::vector<operating_ctrl::operating> messages;
        ros::NodeHandle node;
    pos_index =0;
        // 首先生成所有的消息并存储起来
if (!positionBuffer.empty()) {

    for (int i = 1; i < positionBuffer.size(); ++i) //进行插补计算
    {
        const Position& pos = positionBuffer[i];
        float x2 = pos.x0 - operating_x1; //计算x变化值
        float y2 = pos.y0 - operating_y1; //计算y变化值
        float theta2 = 90 - (std::atan2(y2, x2) * 180.0 / M_PI); // 计算角度变化值
        float dx2 = x2 / numPoints2; //计算x插值
        float dy2 = y2 / numPoints2; //计算y插值
        float dtheta2 = theta2 / numPoints2; //计算角度插值

        for (int j = 0; j < numPoints2; ++j) //发布插值消息
        {
            operating_ctrl::operating diff_msg;
            diff_msg.x2 = dx2;
            diff_msg.y2 = dy2;
            diff_msg.theta2 = dtheta2;

            // 添加开始和结束标识符
            if (i == 1 && j == 0) {
                diff_msg.status = "BA"; // 开始标识符
            } else if (i == positionBuffer.size() -1 && j == numPoints2 - 1) {
                diff_msg.status = "BE"; // 结束标识符
            } else {
                diff_msg.status = ""; // 中间消息没有标识符
            }
            messages.push_back(diff_msg);
        }
        pos_index++; // 更新 pos_index
        operating_x1 = pos.x0;
        operating_y1 = pos.y0;
        operating_theta1 =90 - (std::atan2(y2, x2) * 180.0 / M_PI);
        }

            for (const auto& msg : messages) 
            {
                operating_bufeng.publish(msg);
                ros::spinOnce(); // 确保消息得到处理
            }
            operating_x1 = 0;
            operating_y1 = 0;
            operating_theta1 = 0;
            ROS_INFO("All messages published on operating_quke");
            node.setParam("/now_is_kaicao_bufeng", 1);
    }
}

void localPositionCallback(const ssr_pkg::custommessage::ConstPtr& msg)

{
    ros::NodeHandle node; 
    // 检测起始和结束标识符
     //ROS_INFO("Received custom message with ZA: %s and ZE: %s", msg->ZA.c_str(), msg->ZE.c_str());

    if (msg->ZA == "ZA") 
    {
        isRecording = true;//识别到0A标识符后开始进行记录数据
        positionBuffer.clear();  // 清除旧数据

    } 

    // 如果当前正在记录，添加数据到缓冲区
    if (isRecording) 
    {
        Position pos; // 在循环外部声明 pos
        double first_x, first_y,first_kaicao_theta,first_bufeng_theta;
        // 提取第一个坐标值
        if (!msg->coords.empty()) {
            first_x = msg->coords[0];
            first_y = msg->coords[1];
            // 将第一个坐标值存储在ROS参数服务器中
            first_kaicao_theta = 90 - (std::atan2(first_y, first_x) * 180.0 / M_PI); // 计算角度变化值
            first_bufeng_theta = 90 - (std::atan2(first_y, first_x) * 180.0 / M_PI); // 计算角度变化值
            ros::param::set("/first_kaicao_x", first_x);
            ros::param::set("/first_y", first_y);
            ros::param::set("/first_kaicao_theta",first_kaicao_theta);
            
            operating_x1 = first_x;
            operating_y1 = first_y;
        }

        for (size_t i = 0; i < msg->coords.size(); i += 2) 
        {
            // 提取坐标值
            float x = msg->coords[i];
            float y = msg->coords[i + 1]; // coords 列表中每两个元素表示一个二维坐标
            // 打印提取的数据
            //ROS_INFO("Received position %zu: x=%f, y=%f", i/2, x, y);
            
            // 将位置数据添加到缓冲区
            pos = {x, y}; // 给 pos 赋值
            
            // 将位置数据添加到缓冲区
            positionBuffer.push_back(pos);
        }
        node.getParam("/only_kaicao_or_bufeng", only_kaicao_or_bufeng);
        if (only_kaicao_or_bufeng != 1)
        {
            if (msg->kaicao == 1) //获取消息中的local_d值，判断是否需要开槽
            {
                kaicao_or_bufeng = true;
                ros::param::set("/shifoukaicao", yaokaicao);
            }
            else
            {
                kaicao_or_bufeng = false;  // 否则，执行另一种处理
                ros::param::set("/shifoukaicao", bukaicao);
            }
        }
        else if (only_kaicao_or_bufeng == 1)
        {
            kaicao_or_bufeng = false;
        }
        if (msg->ZE == "ZE") 
        {
            isRecording = false;//识别到0E标识符后结束进行记录数据
            if(kaicao_or_bufeng)//根据kaicao_or_bufeng的值，判断是否需要进行开槽
            {
                kaicaochabuyunsuan();
            }
            else
            {
                ros::param::set("/first_bufeng_x", first_x);
                ros::param::set("/first_bufeng_theta",first_bufeng_theta);
                bufengchabuyunsuan();
            }     
        }
    }
}



int main(int argc, char** argv) 
{
    //节点初始化句柄
    ros::init(argc, argv, "operating_ctrl");
    ros::NodeHandle node; 
    int kaicao_bufeng = 0; // 默认值为 0
    ros::param::param<int>("kaicao_bufeng", kaicao_bufeng, 0); // 获取参数服务器中 kaicao_bufeng 参数的值
    ros::Subscriber sub = node.subscribe("crack_position", 100000, localPositionCallback);
    operating_kaicao = node.advertise<operating_ctrl::operating>("operating_kaicao", 100000);//创建operating_kaicao话题
    operating_bufeng = node.advertise<operating_ctrl::operating>("operating_bufeng", 100000);//创建operating_bufeng话题
    double publish_frequency;
    node.param("/operating_pub_rate", publish_frequency, 1000.0);  // 默认发布频率为 5Hz
    ros::Rate loop_rate(publish_frequency);
    while (ros::ok()) 
    {
        ros::spinOnce();
        loop_rate.sleep();
    }

    return 0;
}
