/*
***************程序说明***************
本程序作业模式，根据局部相机提供的裂缝消息，转化为开槽的控制指令
程序实现步骤: 1.void kaicaoCallback（）实现计算和发布电机真实控制量
            2.int main（）ros主函数
*/
#include "ros/ros.h"
#include "operating_ctrl/operating.h"  
#include "operating_ctrl/kaicao.h" 
#include <std_msgs/Float32.h>
#include <string>
double kaicao_x_s = 5;   // 开槽x方向电机导程，给定的常数值，单位mm
double kaicao_z_s = 1.25;   // 开槽z方向电机导程，给定的常数值，单位mm
double kaicao_theta_s = 23.333333;   // 开槽旋转方向电机导程，给定的常数值，单位mm
double kaicao_z_angle = -1;//开槽z方向下降高度，给定的常数值，单位mm
double kaicao_z_back =1;//开槽z方向提起高度，给定的常数值，单位mm
double kaicao_theta_0 =0;
double kaicao_x_center = 432.4;
double kaicao_r_center = 0;
double kaicao_z_motor_angle;
double sum_kaicao_x = 0;
double sum_kaicao_r = 0;
double first_kaicao_x = 0;
double first_kaicao_theta = 0;
double first_y = 0;
int kaicao_step = 0;
// 在循环外部定义变量保存小数部分的累加值
double kaicao_x_motor_angle_accumulate = 0.0;
double kaicao_theta_motor_angle_accumulate = 0.0;
double A = 1000; //分辨率
double T=1;//运动时间间隔
double kaicao_pub_rate=1;
ros::Publisher kaicao_pub;
ros::Publisher kaicao_z_pub;
struct KaicaoData {
    float x;
    float theta;
};
std::vector<KaicaoData> kaicaoDataBuffer;
bool isRecording = false;
/*
**************函数说明**************
1.订阅话题获取开槽x,d,theta控制量
2.判断d的值，决定是否开槽
3.将开槽x,d,theta控制量转化为电机真实控制量
4.创建话题kaicao_pub发布电机真实控制量
*/
void kaicaoCallback(const std::vector<KaicaoData>& dataBuffer);

void kaicaoPositionCallback(const operating_ctrl::operating::ConstPtr& diff_msg) {
    ros::NodeHandle node;
    operating_ctrl::kaicao kaicao_pub_msg;
    // 如果当前正在记录，添加数据到缓冲区
    if (isRecording) {
        KaicaoData data = {diff_msg->x2, diff_msg->theta2};
        kaicaoDataBuffer.push_back(data);
    }

    // 检测起始和结束标识符
    if (diff_msg->status == "KA") 
    {
        // 添加包含 "KA" 的那一帧数据到缓冲区
        KaicaoData data = {diff_msg->x2, diff_msg->theta2};
        kaicaoDataBuffer.push_back(data);

        isRecording = true;

    } 
    else if (diff_msg->status == "KE") 
    {
        // 如果当前正在记录，处理缓存的数据
        if (isRecording) {
            isRecording = false;
            kaicaoCallback(kaicaoDataBuffer);
        }
    }
}





void kaicaoCallback(const std::vector<KaicaoData>& dataBuffer) 
{
    ros::NodeHandle node;
    operating_ctrl::kaicao kaicao_pub_msg;  
    ROS_INFO("kaicao is working");  
    node.getParam("/first_kaicao_x",first_kaicao_x);
    node.getParam("/first_kaicao_theta",first_kaicao_theta);
    kaicao_pub_msg.kaicao_x_motor_angle = (kaicao_x_center + first_kaicao_x) * 60 / kaicao_x_s / 5;
    kaicao_pub_msg.kaicao_theta_motor_angle = -1 * first_kaicao_theta * kaicao_theta_s * 1000 / 360;
    kaicao_pub.publish(kaicao_pub_msg);
    //node.setParam("/shebei1", 1);

    ros::Duration(5.0).sleep();
    // 作业开始时，设置z电机角度为0.3，以下降z轴
    kaicao_z_motor_angle = kaicao_z_angle / kaicao_z_s * A;
    std_msgs::Float32 z_msg;
    z_msg.data = kaicao_z_motor_angle;
    kaicao_z_pub.publish(z_msg);
    //1.订阅话题获取开槽x,d,theta控制量
    for (const auto& data : dataBuffer) 
    {
        float kaicao_x = data.x;
        float kaicao_theta = data.theta;

        // 计算整数部分和小数部分
        int kaicao_x_motor_angle_integer = static_cast<int>(kaicao_x * 60 / kaicao_x_s / T);
        int kaicao_theta_motor_angle_integer = static_cast<int>(kaicao_theta * kaicao_theta_s * 1000 / 360);

        double kaicao_x_motor_angle_fraction = kaicao_x * 60 / kaicao_x_s / T - kaicao_x_motor_angle_integer;
        double kaicao_theta_motor_angle_fraction = kaicao_theta * kaicao_theta_s * 1000 / 360 - kaicao_theta_motor_angle_integer;

        // 将小数部分累加到之前的累加值中
        kaicao_x_motor_angle_accumulate += kaicao_x_motor_angle_fraction;
        kaicao_theta_motor_angle_accumulate += kaicao_theta_motor_angle_fraction;

        // 判断累加值是否大于等于1，如果是，则进行整数部分补偿
        if (kaicao_x_motor_angle_accumulate >= 1.0)
        {
            kaicao_x_motor_angle_integer += 1;
            kaicao_x_motor_angle_accumulate -= 1.0;
        }

        if (kaicao_theta_motor_angle_accumulate >= 1.0)
        {
            kaicao_theta_motor_angle_integer += 1;
            kaicao_theta_motor_angle_accumulate -= 1.0;
        }

        // 创建话题并发布整数部分
        kaicao_pub_msg.kaicao_x_motor_angle = kaicao_x_motor_angle_integer;
        kaicao_pub_msg.kaicao_theta_motor_angle = -1 * kaicao_theta_motor_angle_integer;
        kaicao_pub.publish(kaicao_pub_msg);
        sum_kaicao_x += kaicao_x_motor_angle_integer;
        sum_kaicao_r += -1 * kaicao_theta_motor_angle_integer;   
        ros::Duration(kaicao_pub_rate).sleep(); // 延时kaicao_pub_rate
        //kaicao_theta_0 = data.theta;
        //kaicao_step++;
        // 设置新值
        //node.setParam("/kaicao_step", kaicao_step);
    }
    node.setParam("/first_y",0);
    //node.setParam("/shebei1", 0);
    kaicao_step = 0;
    //5.作业结束后，设置z电机角度为-0.3，以提起z轴
    kaicao_z_motor_angle = kaicao_z_back / kaicao_z_s * A;
    z_msg.data = kaicao_z_motor_angle;
    kaicao_z_pub.publish(z_msg);
    //4.for循环结束后，设置x，theta电机角度为0，以停止x，theta电机
    kaicao_pub_msg.kaicao_x_motor_angle = (-1 * sum_kaicao_x * T + (-1 * (kaicao_x_center + first_kaicao_x) * 60 / kaicao_x_s)) / 5;
    kaicao_pub_msg.kaicao_theta_motor_angle = 0;
    kaicao_pub.publish(kaicao_pub_msg);
    ros::Duration(5).sleep();
    kaicao_pub_msg.kaicao_x_motor_angle = 0;
    kaicao_pub_msg.kaicao_theta_motor_angle = 0;
    kaicao_pub.publish(kaicao_pub_msg);
    kaicaoDataBuffer.clear();  // 清除旧数据 
    //ros::Duration(6).sleep();
         
    node.setParam("/now_is_kaicao_bufeng", 1); 
    sum_kaicao_x = 0;
    sum_kaicao_r = 0; 
}

/*
**************函数说明**************
1.初始化ROS节点句柄
2.订阅operating_kaicao话题
3.发布kaicao_pub话题
4.kaicao_pub_rate挂载参数服务器
*/
int main(int argc, char** argv) 
{
    //1.初始化ROS节点句柄
    ros::init(argc, argv, "kaicao_ctrl");
    ros::NodeHandle node;
    node.param("kaicao_z_angle", kaicao_z_angle, 1.0); // 默认值为1
    //2.订阅 "operating_kaicao" 话题
    ros::Subscriber sub = node.subscribe("operating_kaicao", 100000, kaicaoPositionCallback);
    //3.创建 "kaicao_pub" 发布者
    kaicao_pub = node.advertise<operating_ctrl::kaicao>("kaicao_pub", 100000);
    kaicao_z_pub = node.advertise<std_msgs::Float32>("/kaicao_z_pub", 100000);
    //4.获取发布频率参数，如果没有指定，则设置默认值为 1


    while (ros::ok()) 
    {
        
        ros::spinOnce();
        // 在循环中添加以下行以控制循环频率
    }

    return 0;
}