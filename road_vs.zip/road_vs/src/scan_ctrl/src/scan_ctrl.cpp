/*
***************程序说明***************
本程序扫描模式，根据全局相机提供的裂缝消息，转化为驱动底盘相机运动的控制指令
程序实现步骤: 1.void interpolateAndPublish（）实现插补运算
            2.int main（）ros主函数
*/
#include "ros/ros.h"
#include "geometry_msgs/Pose2D.h"
double s = 1;   //电机导程，给定的常数值，单位mm
double A = 1000; //分辨率
double T=1;//运动时间间隔
double cam_ctrl_current_x = 0.0; //初始化
double cam_ctrl_current_y = 0.0; //初始化
double local_cam_ctrl_pub_rate=1;
int numPoints = 1; // 插值点数量
double current_mode;
double last_mode;
int crack_capture;
ros::Publisher cam_ctrl_pub;
/*
**************函数说明**************
1.进行差值计算，得出需要的控制变量
2.根据控制变量进行插补运算，设置插补点为numPoints
3.将裂缝控制量转化为电机真实控制量
4.创建话题发布插补值
5.更新当前位置
*/
void interpolateAndPublish(double cam_ctrl_new_x, double cam_ctrl_new_y) {
    ros::NodeHandle nh;

    geometry_msgs::Pose2D cam_ctrl_angle_msg;
    cam_ctrl_angle_msg.x = cam_ctrl_new_x;
    cam_ctrl_angle_msg.y = cam_ctrl_new_y;
    cam_ctrl_pub.publish(cam_ctrl_angle_msg);   
}
/*
**************函数说明**************
1.初始化ROS节点句柄
2.订阅global_position话题
3.发布话题cam_ctrl_pub
4.发布频率local_cam_ctrl_pub_rate挂载参数服务器
*/
int main(int argc, char **argv) 
{
    ros::init(argc, argv, "scan_ctrl");
    ros::NodeHandle nh;

    // 使用预定义的4组数据//5.56
    std::vector<std::pair<double, double>> custom_data = {{-4036, 3006}, {-4036, 9503}, {-4036, 16000}, {-7848, 16000}, {-7848, 9503}, {-7848, 3006},{0, 0}};
    cam_ctrl_pub = nh.advertise<geometry_msgs::Pose2D>("cam_ctrl_pub", 10);
    // 检查当前模式是否为2
    while (ros::ok()) 
    {

        // 获取参数服务器中的/current_mode的值
        nh.getParam("/current_mode", current_mode);
        if (current_mode == 2 && current_mode != last_mode) 
        {
            //last_mode = current_mode;
            cam_ctrl_current_x = 0;
            cam_ctrl_current_y = 0;
        // 使用预定义数据进行插值计算和控制
            for (const auto &data : custom_data) 
            {
                interpolateAndPublish(data.first, data.second);
                ros::Duration(2.0).sleep(); // 添加5秒延时
                nh.setParam("/crack_capture", 1);
                ros::Duration(3.0).sleep(); // 添加5秒延时
            }
        }
        last_mode = current_mode;
        ros::spinOnce();
    }
    return 0;
}
