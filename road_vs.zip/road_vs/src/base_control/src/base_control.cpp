/*
***************程序说明***************
本程序导航模式，手动模式。根据路径规划节点提供的线速度，角速度消息，进行底盘逆运动学解算出四个轮子各自的线速度，角度，并转化为电机实际控制量
程序实现步骤: 1.void shoudongVelCallback（）手动模式下的底盘解算
            2.void navigationVelCallback（）导航模式下的底盘解算
            5.int main（）ros主函数
*/
#include "ros/ros.h"
#include "base_control/basecontrol.h"
#include <cmath>
#include "geometry_msgs/Twist.h" 
#include "std_msgs/Float32.h"
int fangxianghuizheng = 0;
double publish_frequency = 1000;
double v0 = 0.0;  // 全局变量用于存储线速度
double vx = 0.0;  // 全局变量用于存储线速度
double vy = 0.0;  // 全局变量用于存储线速度
double w0 = 0.0;  // 全局变量用于存储角速度
double L = 2.02; // 底盘长度m
double B = 1.7; // 底盘宽度m
double wheel_s = 1000;//转向电机分辨率
double Vel_i_fl = 1;//左前轮传动比
double Vel_i_fr = 1;//右前轮传动比   
double Angel_i_fl = (2 * M_PI)/(100 * wheel_s );//左前轮传动
double Angel_i_fr = (2 * M_PI)/(100 * wheel_s );//右前轮传动比
double Angel_i_rl = (2 * M_PI)/(100 * wheel_s );//左后轮传动
double Angel_i_rr = (2 * M_PI)/(100 * wheel_s );//右后轮传动比
double wheel_motor_fl = 0.24;//m轮子直径
double wheel_motor_fr = 0.24;//m轮子直径
double wheel_motor_rl = 0.24;//m轮子直径
double wheel_motor_rr = 0.24;//m轮子直径
double T = 0.1;//1/10;采样频率，发布话题的频率为50HZ
double V_fl = 0 ;
double V_rl = 0 ;
double V_fr = 0 ;
double V_rr = 0;
double theta_fl = 0 ;
double theta_fr = 0 ;
double theta_rl = 0 ;
double theta_rr = 0 ;
double Vel_motor_fl = 0 ;
double Vel_motor_rl = 0 ;
double Vel_motor_fr = 0 ;
double Vel_motor_rr = 0 ;
double Angel_motor_fl = 0 ;
double Angel_motor_rl = 0 ; 
double Angel_motor_fr = 0 ;
double Angel_motor_rr = 0 ;
int k;
int j;
ros::Publisher pub;
/*
**************函数说明**************
1.手动模式
2.底盘解算
3.阿克曼前轮转向模式
4.原地转向模式
5.侧移模式
*/
void shoudongVelCallback(const geometry_msgs::Twist::ConstPtr& cmd_vel_msg) 
{
    v0 = cmd_vel_msg->linear.x;
    w0 = cmd_vel_msg->angular.z;
    if (v0 == 0 && w0 == 0) 
    {
        Vel_motor_fl = 0;
        Vel_motor_rl = 0;
        Vel_motor_fr = 0;
        Vel_motor_rr = 0;
        Angel_motor_fl = 0;
        Angel_motor_rl = 0;
        Angel_motor_fr = 0;
        Angel_motor_rr = 0;
    }else if (v0 == 0 && w0 != 0) 
    {
        Vel_motor_fl = 0;
        Vel_motor_rl = 0;
        Vel_motor_fr = 0;
        Vel_motor_rr = 0;
        // 计算 theta_fl 和 theta_rl
        theta_fl = w0;
        theta_rl = w0;
        // 计算 theta_fr 和 theta_rr
        theta_fr = w0;
        theta_rr = w0;
        // 计算 Vel_motor_fl, Vel_motor_rl, Vel_motor_fr, Vel_motor_rr
        Angel_motor_fl = -1 * theta_fl/Angel_i_fl;
        Angel_motor_rl = -1 * theta_rl/Angel_i_rl;
        Angel_motor_fr = -1 * theta_fr/Angel_i_fr;
        Angel_motor_rr = -1 * theta_rr/Angel_i_rr;
    }else if (v0 != 0 && w0 == 0) 
    {
        // 计算 V_fl, V_rl, V_fr, V_rr
        V_fl = v0;
        V_rl = v0;
        V_fr = v0;
        V_rr = v0;
        Vel_motor_fl = (V_fl * Vel_i_fl * 60) / (M_PI * wheel_motor_fl);
        Vel_motor_rl = Vel_motor_fl;
        Vel_motor_fr = (V_fr * Vel_i_fr * 60) / (M_PI * wheel_motor_fr);
        Vel_motor_rr = Vel_motor_fr;
        Angel_motor_fl = 0;
        Angel_motor_rl = 0;
        Angel_motor_fr = 0;
        Angel_motor_rr = 0;
    }else if (v0 != 0 && v0 != 0.002 && v0 != 0.001 && w0 != 0 ) 
    {
        // 计算 theta_fl 和 theta_rl
        theta_fl = w0;
        theta_rl = w0;
        // 计算 theta_fr 和 theta_rr
        theta_fr = w0;
        theta_rr = w0;
        // 计算 V_fl, V_rl, V_fr, V_rr
        V_fl = v0;
        V_rl = v0;
        V_fr = v0;
        V_rr = v0;
        Vel_motor_fl = (V_fl * Vel_i_fl * 60) / (M_PI * wheel_motor_fl);
        Vel_motor_rl = Vel_motor_fl;
        Vel_motor_fr = (V_fr * Vel_i_fr * 60) / (M_PI * wheel_motor_fr);
        Vel_motor_rr = Vel_motor_fr;
        // 计算 Vel_motor_fl, Vel_motor_rl, Vel_motor_fr, Vel_motor_rr
        Angel_motor_fl = -1 * theta_fl/Angel_i_fl;
        Angel_motor_rl = -1 * theta_rl/Angel_i_rl;
        Angel_motor_fr = -1 * theta_fr/Angel_i_fr;
        Angel_motor_rr = -1 * theta_rr/Angel_i_rr;
    }else if ( (w0 == 1.0 || w0 == -1.0) && v0 == 0.002 )
    {
        //原地转向模式前摇
        // 计算 R_fl 和 R_rl                            
        // 计算R, R_fr 和 R_rr
        double R_fl = sqrt(pow((B/2.0), 2) + pow(L / 2.0, 2));
        double R_fr = sqrt(pow((B/2.0), 2) + pow(L / 2.0, 2));
        double R_rl = sqrt(pow((B/2.0), 2) + pow(L / 2.0, 2));
        double R_rr = sqrt(pow((B/2.0), 2) + pow(L / 2.0, 2));
        // 计算 theta_fl 和 theta_rl
        theta_fl = -atan((L / 2.0) / (B / 2.0));
        theta_rl = atan((L / 2.0) / (B / 2.0));
        // 计算 theta_fr 和 theta_rr
        theta_fr =  atan((L / 2.0) / (B / 2.0));
        theta_rr = -atan((L / 2.0) / (B / 2.0));
        // 计算 V_fl, V_rl, V_fr, V_rr
        V_fl = 0;
        V_rl = 0;
        V_fr = 0;
        V_rr = 0;
        Vel_motor_fl = 0;
        Vel_motor_rl = 0;
        Vel_motor_fr = 0;        
        Vel_motor_rr = 0;
        Angel_motor_fl = -theta_fl/Angel_i_fl;
        Angel_motor_rl=-Angel_motor_fl;
        Angel_motor_fr = -theta_fr/Angel_i_fr;
        Angel_motor_rr=-Angel_motor_fr;                 
    }else if (v0 == 0.001 && (w0 == 1.0 || w0 == -1.0)) 
    {
        //原地转向模式
        // 计算 R_fl 和 R_rl                            
        // 计算R, R_fr 和 R_rr
        double R_fl = sqrt(pow((B/2.0), 2) + pow(L / 2.0, 2));
        double R_fr = sqrt(pow((B/2.0), 2) + pow(L / 2.0, 2));
        double R_rl = sqrt(pow((B/2.0), 2) + pow(L / 2.0, 2));
        double R_rr = sqrt(pow((B/2.0), 2) + pow(L / 2.0, 2));
        // 计算 theta_fl 和 theta_rl
        theta_fl = -atan((L / 2.0) / (B / 2.0));
        theta_rl = atan((L / 2.0) / (B / 2.0));
        // 计算 theta_fr 和 theta_rr
        theta_fr =  atan((L / 2.0) / (B / 2.0));
        theta_rr = -atan((L / 2.0) / (B / 2.0));
        // 计算 V_fl, V_rl, V_fr, V_rr
        V_fl = w0 * R_fl;
        V_rl = w0 * R_rl;
        V_fr = w0 * R_fr;
        V_rr = w0 * R_rr;
        Vel_motor_fl = -1 * (V_fl * Vel_i_fl * 60) / (M_PI * wheel_motor_fl);
        Vel_motor_rl = Vel_motor_fl;
        Vel_motor_fr = (V_fr * Vel_i_fr * 60) / (M_PI * wheel_motor_fr);        
        Vel_motor_rr = Vel_motor_fr;
        Angel_motor_fl = -theta_fl/Angel_i_fl;
        Angel_motor_rl=-Angel_motor_fl;
        Angel_motor_fr = -theta_fr/Angel_i_fr;
        Angel_motor_rr=-Angel_motor_fr;                 
    }
    
    // 创建Twist消息
    base_control::basecontrol control_cmd;         
    control_cmd.Vel_motor_fl = Vel_motor_fl;
    control_cmd.Vel_motor_rl = Vel_motor_rl;
    control_cmd.Vel_motor_fr = -1 * Vel_motor_fr;
    control_cmd.Vel_motor_rr = -1 * Vel_motor_rr;
    control_cmd.Angel_motor_fl = Angel_motor_fl;
    control_cmd.Angel_motor_rl = Angel_motor_rl;
    control_cmd.Angel_motor_fr = Angel_motor_fr;
    control_cmd.Angel_motor_rr = Angel_motor_rr;
    pub.publish(control_cmd);
}
//导航模式
void cmdVelCallback(const geometry_msgs::Twist::ConstPtr& cmd_vel_msg) 
{
    double V_fl, V_rl, V_fr, V_rr, theta_fl, theta_fr ,theta_rl,theta_rr, Vel_motor_fl,Vel_motor_rl,Vel_motor_fr,Vel_motor_rr,Angel_motor_fl,Angel_motor_rl,Angel_motor_fr,Angel_motor_rr;
    v0 = cmd_vel_msg->linear.x;
    w0 = cmd_vel_msg->angular.z;
    if (v0 != 0.002 && w0 != 1 && v0 != 0) 
    {
        // 计算 theta_fl 和 theta_rl
        theta_fl = w0;
        theta_rl = w0;
        // 计算 theta_fr 和 theta_rr
        theta_fr = w0;
        theta_rr = w0;
        // 计算 V_fl, V_rl, V_fr, V_rr
        V_fl = v0;
        V_rl = v0;
        V_fr = v0;
        V_rr = v0;
        Vel_motor_fl = (V_fl * Vel_i_fl * 60) / (M_PI * wheel_motor_fl);
        Vel_motor_rl = Vel_motor_fl;
        Vel_motor_fr = (V_fr * Vel_i_fr * 60) / (M_PI * wheel_motor_fr);
        Vel_motor_rr = Vel_motor_fr;
        // 计算 Vel_motor_fl, Vel_motor_rl, Vel_motor_fr, Vel_motor_rr
        Angel_motor_fl = -1 * theta_fl/Angel_i_fl;
        Angel_motor_rl = -1 * theta_rl/Angel_i_rl;
        Angel_motor_fr = -1 * theta_fr/Angel_i_fr;
        Angel_motor_rr = -1 * theta_rr/Angel_i_rr;
    }else if ( w0 != 0.0 && v0 ==0.0 )
    {
        //原地转向模式
        // 计算 R_fl 和 R_rl                            
        // 计算R, R_fr 和 R_rr
        double R_fl = sqrt(pow((B/2.0), 2) + pow(L / 2.0, 2));
        double R_fr = sqrt(pow((B/2.0), 2) + pow(L / 2.0, 2));
        double R_rl = sqrt(pow((B/2.0), 2) + pow(L / 2.0, 2));
        double R_rr = sqrt(pow((B/2.0), 2) + pow(L / 2.0, 2));
        // 计算 theta_fl 和 theta_rl
        theta_fl = -atan((L / 2.0) / (B / 2.0));
        theta_rl = atan((L / 2.0) / (B / 2.0));
        // 计算 theta_fr 和 theta_rr
        theta_fr =  atan((L / 2.0) / (B / 2.0));
        theta_rr = -atan((L / 2.0) / (B / 2.0));
        // 计算 V_fl, V_rl, V_fr, V_rr
        V_fl = w0 * R_fl;
        V_rl = w0 * R_rl;
        V_fr = w0 * R_fr;
        V_rr = w0 * R_rr;
        Vel_motor_fl = -1 * (V_fl * Vel_i_fl * 60) / (M_PI * wheel_motor_fl);
        Vel_motor_rl = Vel_motor_fl;
        Vel_motor_fr = (V_fr * Vel_i_fr * 60) / (M_PI * wheel_motor_fr);        
        Vel_motor_rr = Vel_motor_fr;
        Angel_motor_fl = -theta_fl/Angel_i_fl;
        Angel_motor_rl=-Angel_motor_fl;
        Angel_motor_fr = -theta_fr/Angel_i_fr;
        Angel_motor_rr=-Angel_motor_fr;                 
    }else if ( w0 == 1 && v0 == 0.002 )
    {
        //原地转向模式前摇
        // 计算 R_fl 和 R_rl                            
        // 计算R, R_fr 和 R_rr
        double R_fl = sqrt(pow((B/2.0), 2) + pow(L / 2.0, 2));
        double R_fr = sqrt(pow((B/2.0), 2) + pow(L / 2.0, 2));
        double R_rl = sqrt(pow((B/2.0), 2) + pow(L / 2.0, 2));
        double R_rr = sqrt(pow((B/2.0), 2) + pow(L / 2.0, 2));
        // 计算 theta_fl 和 theta_rl
        theta_fl = -atan((L / 2.0) / (B / 2.0));
        theta_rl = atan((L / 2.0) / (B / 2.0));
        // 计算 theta_fr 和 theta_rr
        theta_fr =  atan((L / 2.0) / (B / 2.0));
        theta_rr = -atan((L / 2.0) / (B / 2.0));
        // 计算 V_fl, V_rl, V_fr, V_rr
        V_fl = 0;
        V_rl = 0;
        V_fr = 0;
        V_rr = 0;
        Vel_motor_fl = 0;
        Vel_motor_rl = 0;
        Vel_motor_fr = 0;        
        Vel_motor_rr = 0;
        Angel_motor_fl = -theta_fl/Angel_i_fl;
        Angel_motor_rl=-Angel_motor_fl;
        Angel_motor_fr = -theta_fr/Angel_i_fr;
        Angel_motor_rr=-Angel_motor_fr;                 
    }else if ( w0 == 0.0 && v0 == 0.0 )
    {
        V_fl = 0;
        V_rl = 0;
        V_fr = 0;
        V_rr = 0;
        theta_fl = 0;
        theta_fr = 0;
        theta_rl = 0;
        theta_rr = 0;
        Vel_motor_fl = 0;        
        Vel_motor_rl = 0;
        Vel_motor_fr = 0;
        Vel_motor_rr = 0;
        // 计算 Vel_motor_fl, Vel_motor_rl, Vel_motor_fr, Vel_motor_rr
        Angel_motor_fl = 0;
        Angel_motor_rl=0;
        Angel_motor_fr =0;
        Angel_motor_rr=0; 
    } 
        // 创建Twist消息
        base_control::basecontrol control_cmd;
        control_cmd.Vel_motor_fl = Vel_motor_fl;
        control_cmd.Vel_motor_rl = Vel_motor_rl;
        control_cmd.Vel_motor_fr = -1 * Vel_motor_fr;
        control_cmd.Vel_motor_rr = -1 * Vel_motor_rr;
        control_cmd.Angel_motor_fl = Angel_motor_fl;
        control_cmd.Angel_motor_rl = Angel_motor_rl;
        control_cmd.Angel_motor_fr = Angel_motor_fr;
        control_cmd.Angel_motor_rr = Angel_motor_rr;
        pub.publish(control_cmd);
}
int main(int argc, char** argv) 
{
    // 初始化ROS节点
    ros::init(argc, argv, "base_control");
    // 创建节点句柄
    ros::NodeHandle node_handle;
    // 获取发布频率，默认为10hz

    if (!node_handle.getParam("/control_topic_rate", publish_frequency)) 
    {
        publish_frequency = 1000.0;  
        node_handle.setParam("/control_topic_rate", publish_frequency);
    }

    ros::Subscriber cmd_vel_sub = node_handle.subscribe<geometry_msgs::Twist>("/auto_cmd_vel", 1000, cmdVelCallback);
    ros::Subscriber cmd_vel_sub2 = node_handle.subscribe<geometry_msgs::Twist>("/cmd_vel", 1000, shoudongVelCallback);
    pub = node_handle.advertise<base_control::basecontrol>("/control_topic", 1000);
    ros::Rate rate(publish_frequency);

    // 进入ROS循环
    while (ros::ok()) 
    {       
        ros::spinOnce();
        rate.sleep();
    }

    return 0;
}